import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 40 }).notNull().unique(),
  name: varchar("name", { length: 180 }).notNull(),
  city: varchar("city", { length: 100 }).notNull(),
  managerId: int("managerId"),
  status: mysqlEnum("status", ["planned", "in_progress", "completed", "on_hold"]).default("planned").notNull(),
  budget: decimal("budget", { precision: 16, scale: 2 }).default("0").notNull(),
  progress: int("progress").default(0).notNull(),
  startDate: timestamp("startDate"),
  dueDate: timestamp("dueDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const maintenanceRequests = mysqlTable("maintenance_requests", {
  id: int("id").autoincrement().primaryKey(),
  requestCode: varchar("requestCode", { length: 40 }).notNull().unique(),
  projectId: int("projectId"),
  location: varchar("location", { length: 180 }).notNull(),
  description: text("description").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium").notNull(),
  status: mysqlEnum("status", ["open", "in_progress", "resolved", "closed"]).default("open").notNull(),
  assignedTeam: varchar("assignedTeam", { length: 160 }),
  createdBy: int("createdBy"),
  closedAt: timestamp("closedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const qualityInspections = mysqlTable("quality_inspections", {
  id: int("id").autoincrement().primaryKey(),
  inspectionCode: varchar("inspectionCode", { length: 40 }).notNull().unique(),
  projectId: int("projectId").notNull(),
  inspectorId: int("inspectorId"),
  complianceRate: int("complianceRate").default(0).notNull(),
  criticalObservation: int("criticalObservation").default(0).notNull(),
  notes: text("notes"),
  inspectedAt: timestamp("inspectedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const productionEntries = mysqlTable("production_entries", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  periodType: mysqlEnum("periodType", ["daily", "weekly"]).notNull(),
  periodStart: timestamp("periodStart").notNull(),
  unit: varchar("unit", { length: 40 }).notNull(),
  plannedQuantity: decimal("plannedQuantity", { precision: 14, scale: 2 }).notNull(),
  actualQuantity: decimal("actualQuantity", { precision: 14, scale: 2 }).notNull(),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  recipientId: int("recipientId").notNull(),
  type: mysqlEnum("type", ["deadline_overrun", "critical_quality", "status_update"]).notNull(),
  title: varchar("title", { length: 180 }).notNull(),
  body: text("body").notNull(),
  readAt: timestamp("readAt"),
  dedupeKey: varchar("dedupeKey", { length: 180 }).notNull().unique(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;


export const roleAssignments = mysqlTable("role_assignments", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  projectId: int("projectId"),
  role: mysqlEnum("role", ["general_manager", "project_manager", "quality_engineer", "maintenance_team", "production_supervisor"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const attachments = mysqlTable("attachments", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId"),
  inspectionId: int("inspectionId"),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 500 }).notNull(),
  url: text("url").notNull(),
  mimeType: varchar("mimeType", { length: 120 }).notNull(),
  uploadedBy: int("uploadedBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const reports = mysqlTable("reports", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 180 }).notNull(),
  module: mysqlEnum("module", ["projects", "maintenance", "quality", "production", "portfolio"]).notNull(),
  periodType: mysqlEnum("periodType", ["daily", "weekly", "monthly"]).notNull(),
  periodStart: timestamp("periodStart").notNull(),
  periodEnd: timestamp("periodEnd").notNull(),
  status: mysqlEnum("status", ["draft", "in_review", "approved"]).default("draft").notNull(),
  pdfUrl: text("pdfUrl"),
  excelUrl: text("excelUrl"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  entityType: varchar("entityType", { length: 80 }).notNull(),
  entityId: int("entityId").notNull(),
  action: varchar("action", { length: 80 }).notNull(),
  beforeJson: text("beforeJson"),
  afterJson: text("afterJson"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});


export type InsertRoleAssignment = typeof roleAssignments.$inferInsert;
export type InsertAttachment = typeof attachments.$inferInsert;
export type InsertReport = typeof reports.$inferInsert;
export type InsertAuditLog = typeof auditLogs.$inferInsert;


export type InsertMaintenanceRequest = typeof maintenanceRequests.$inferInsert;
export type InsertQualityInspection = typeof qualityInspections.$inferInsert;
export type InsertProductionEntry = typeof productionEntries.$inferInsert;

// ---------------------------------------------------------------------------
// Planning module: WBS, activities/dependencies (CPM), cost catalog, cost entries
// ---------------------------------------------------------------------------

export const wbsNodes = mysqlTable("wbs_nodes", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  parentId: int("parentId"),
  code: varchar("code", { length: 40 }).notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const activities = mysqlTable("activities", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  wbsNodeId: int("wbsNodeId"),
  code: varchar("code", { length: 40 }).notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate").notNull(),
  progress: int("progress").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const activityDependencies = mysqlTable("activity_dependencies", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  predecessorId: int("predecessorId").notNull(),
  successorId: int("successorId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const costCatalogItems = mysqlTable("cost_catalog_items", {
  id: int("id").autoincrement().primaryKey(),
  itemCode: varchar("itemCode", { length: 40 }).notNull().unique(),
  description: varchar("description", { length: 300 }).notNull(),
  category: varchar("category", { length: 120 }).notNull(),
  unit: varchar("unit", { length: 30 }).notNull(),
  unitPrice: decimal("unitPrice", { precision: 14, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 10 }).default("SAR").notNull(),
  sourcePage: varchar("sourcePage", { length: 40 }),
  sourceNote: text("sourceNote"),
  isActive: int("isActive").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const costEntries = mysqlTable("cost_entries", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull(),
  wbsNodeId: int("wbsNodeId"),
  activityId: int("activityId"),
  catalogItemId: int("catalogItemId").notNull(),
  quantity: decimal("quantity", { precision: 14, scale: 3 }).notNull(),
  unitPriceSnapshot: decimal("unitPriceSnapshot", { precision: 14, scale: 2 }).notNull(),
  plannedCost: decimal("plannedCost", { precision: 16, scale: 2 }).notNull(),
  actualCost: decimal("actualCost", { precision: 16, scale: 2 }),
  progress: int("progress").default(0).notNull(),
  measurementDate: timestamp("measurementDate"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WbsNode = typeof wbsNodes.$inferSelect;
export type InsertWbsNode = typeof wbsNodes.$inferInsert;
export type Activity = typeof activities.$inferSelect;
export type InsertActivity = typeof activities.$inferInsert;
export type ActivityDependency = typeof activityDependencies.$inferSelect;
export type InsertActivityDependency = typeof activityDependencies.$inferInsert;
export type CostCatalogItem = typeof costCatalogItems.$inferSelect;
export type InsertCostCatalogItem = typeof costCatalogItems.$inferInsert;
export type CostEntry = typeof costEntries.$inferSelect;
export type InsertCostEntry = typeof costEntries.$inferInsert;
