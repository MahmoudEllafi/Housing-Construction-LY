CREATE TABLE `maintenance_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`requestCode` varchar(40) NOT NULL,
	`projectId` int,
	`location` varchar(180) NOT NULL,
	`description` text NOT NULL,
	`priority` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
	`status` enum('open','in_progress','resolved','closed') NOT NULL DEFAULT 'open',
	`assignedTeam` varchar(160),
	`createdBy` int,
	`closedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `maintenance_requests_id` PRIMARY KEY(`id`),
	CONSTRAINT `maintenance_requests_requestCode_unique` UNIQUE(`requestCode`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`recipientId` int NOT NULL,
	`type` enum('deadline_overrun','critical_quality','status_update') NOT NULL,
	`title` varchar(180) NOT NULL,
	`body` text NOT NULL,
	`readAt` timestamp,
	`dedupeKey` varchar(180) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`),
	CONSTRAINT `notifications_dedupeKey_unique` UNIQUE(`dedupeKey`)
);
--> statement-breakpoint
CREATE TABLE `production_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`periodType` enum('daily','weekly') NOT NULL,
	`periodStart` timestamp NOT NULL,
	`unit` varchar(40) NOT NULL,
	`plannedQuantity` decimal(14,2) NOT NULL,
	`actualQuantity` decimal(14,2) NOT NULL,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `production_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`code` varchar(40) NOT NULL,
	`name` varchar(180) NOT NULL,
	`city` varchar(100) NOT NULL,
	`managerId` int,
	`status` enum('planned','in_progress','completed','on_hold') NOT NULL DEFAULT 'planned',
	`budget` decimal(16,2) NOT NULL DEFAULT '0',
	`progress` int NOT NULL DEFAULT 0,
	`startDate` timestamp,
	`dueDate` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`),
	CONSTRAINT `projects_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `quality_inspections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`inspectionCode` varchar(40) NOT NULL,
	`projectId` int NOT NULL,
	`inspectorId` int,
	`complianceRate` int NOT NULL DEFAULT 0,
	`criticalObservation` int NOT NULL DEFAULT 0,
	`notes` text,
	`inspectedAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quality_inspections_id` PRIMARY KEY(`id`),
	CONSTRAINT `quality_inspections_inspectionCode_unique` UNIQUE(`inspectionCode`)
);
