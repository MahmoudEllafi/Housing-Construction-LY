CREATE TABLE `activities` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`wbsNodeId` int,
	`code` varchar(40) NOT NULL,
	`name` varchar(200) NOT NULL,
	`startDate` timestamp NOT NULL,
	`endDate` timestamp NOT NULL,
	`progress` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `activities_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `activity_dependencies` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`predecessorId` int NOT NULL,
	`successorId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `activity_dependencies_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `cost_catalog_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`itemCode` varchar(40) NOT NULL,
	`description` varchar(300) NOT NULL,
	`category` varchar(120) NOT NULL,
	`unit` varchar(30) NOT NULL,
	`unitPrice` decimal(14,2) NOT NULL,
	`currency` varchar(10) NOT NULL DEFAULT 'SAR',
	`sourcePage` varchar(40),
	`sourceNote` text,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `cost_catalog_items_id` PRIMARY KEY(`id`),
	CONSTRAINT `cost_catalog_items_itemCode_unique` UNIQUE(`itemCode`)
);
--> statement-breakpoint
CREATE TABLE `cost_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`wbsNodeId` int,
	`activityId` int,
	`catalogItemId` int NOT NULL,
	`quantity` decimal(14,3) NOT NULL,
	`unitPriceSnapshot` decimal(14,2) NOT NULL,
	`plannedCost` decimal(16,2) NOT NULL,
	`actualCost` decimal(16,2),
	`progress` int NOT NULL DEFAULT 0,
	`measurementDate` timestamp,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `cost_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `wbs_nodes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`parentId` int,
	`code` varchar(40) NOT NULL,
	`name` varchar(200) NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `wbs_nodes_id` PRIMARY KEY(`id`)
);
