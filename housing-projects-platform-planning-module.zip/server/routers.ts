import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { assignRole, createAttachment, createMaintenanceRequest, createNotification, createProductionEntry, createProject, createQualityInspection, createReport, listAttachments, listMaintenanceRequests, listNotifications, listProductionEntries, listProjects, listQualityInspections, listReports, markNotificationRead, writeAuditLog } from "./db";
import { createWbsNode, deleteWbsNode, listWbsNodes, createActivity, updateActivity, deleteActivity, listActivities, createActivityDependency, deleteActivityDependency, listActivityDependencies, listCostCatalog, getCostCatalogItem, listCostEntries, createCostEntry, updateCostEntry, deleteCostEntry } from "./db";
import { computeCriticalPath, validateDependencyEdge } from "./cpm";
import { computeEvm } from "./evm";
import { computeWbsStats } from "./wbs";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  projects: router({
    list: protectedProcedure.query(() => listProjects()),
    create: protectedProcedure
      .input(z.object({
        code: z.string().min(3).max(40),
        name: z.string().min(2).max(180),
        city: z.string().min(2).max(100),
        status: z.enum(["planned", "in_progress", "completed", "on_hold"]).default("planned"),
        budget: z.string().regex(/^\d+(\.\d{1,2})?$/).default("0"),
        progress: z.number().int().min(0).max(100).default(0),
      }))
      .mutation(({ input, ctx }) => createProject({ ...input, managerId: ctx.user.id })),
  }),

  maintenance: router({
    list: protectedProcedure.query(() => listMaintenanceRequests()),
    create: protectedProcedure.input(z.object({
      requestCode: z.string().min(3).max(40), projectId: z.number().int().positive().nullable().optional(), location: z.string().min(2).max(180), description: z.string().min(5), priority: z.enum(["low", "medium", "high", "critical"]).default("medium"), assignedTeam: z.string().max(160).optional(),
    })).mutation(({ input, ctx }) => createMaintenanceRequest({ ...input, createdBy: ctx.user.id })),
  }),

  quality: router({
    list: protectedProcedure.query(() => listQualityInspections()),
    create: protectedProcedure.input(z.object({
      inspectionCode: z.string().min(3).max(40), projectId: z.number().int().positive(), complianceRate: z.number().int().min(0).max(100), criticalObservation: z.boolean().default(false), notes: z.string().optional(), inspectedAt: z.coerce.date().optional(),
    })).mutation(async ({ input, ctx }) => {
      const inspection = await createQualityInspection({ ...input, criticalObservation: input.criticalObservation ? 1 : 0, inspectorId: ctx.user.id });
      if (input.criticalObservation) {
        await createNotification({ recipientId: ctx.user.id, type: "critical_quality", title: "ملاحظة جودة حرجة", body: `تم تسجيل فحص حرج ${input.inspectionCode}`, dedupeKey: `critical-quality-${input.inspectionCode}`, createdAt: new Date() });
      }
      return inspection;
    }),
  }),

  production: router({
    list: protectedProcedure.query(() => listProductionEntries()),
    create: protectedProcedure.input(z.object({
      projectId: z.number().int().positive(), periodType: z.enum(["daily", "weekly"]), periodStart: z.coerce.date(), unit: z.string().min(1).max(40), plannedQuantity: z.string().regex(/^\d+(\.\d{1,2})?$/), actualQuantity: z.string().regex(/^\d+(\.\d{1,2})?$/),
    })).mutation(({ input, ctx }) => createProductionEntry({ ...input, createdBy: ctx.user.id })),
  }),

  reports: router({
    list: protectedProcedure.query(() => listReports()),
    create: protectedProcedure
      .input(z.object({
        title: z.string().min(3).max(180),
        module: z.enum(["projects", "maintenance", "quality", "production", "portfolio"]),
        periodType: z.enum(["daily", "weekly", "monthly"]),
        periodStart: z.coerce.date(),
        periodEnd: z.coerce.date(),
      }).refine((value) => value.periodEnd >= value.periodStart, { message: "تاريخ نهاية التقرير يجب أن يكون بعد بدايته", path: ["periodEnd"] }))
      .mutation(async ({ input, ctx }) => {
        const report = await createReport({ ...input, createdBy: ctx.user.id });
        await writeAuditLog({ userId: ctx.user.id, entityType: "report", entityId: report.id, action: "created", afterJson: JSON.stringify(input) });
        return report;
      }),
  }),

  attachments: router({
    list: protectedProcedure.input(z.object({ projectId: z.number().int().positive().optional(), inspectionId: z.number().int().positive().optional() }).default({})).query(({ input }) => listAttachments(input)),
    create: protectedProcedure.input(z.object({ projectId: z.number().int().positive().optional(), inspectionId: z.number().int().positive().optional(), fileName: z.string().min(1).max(255), fileKey: z.string().min(1).max(500), url: z.string().url(), mimeType: z.string().min(1).max(120) })).mutation(({ input, ctx }) => createAttachment({ ...input, uploadedBy: ctx.user.id })),
  }),

  notifications: router({
    list: protectedProcedure.query(({ ctx }) => listNotifications(ctx.user.id)),
    markRead: protectedProcedure.input(z.object({ id: z.number().int().positive() })).mutation(({ input, ctx }) => markNotificationRead(input.id, ctx.user.id)),
  }),

  planning: router({
    wbs: router({
      list: protectedProcedure
        .input(z.object({ projectId: z.number().int().positive() }))
        .query(({ input }) => listWbsNodes(input.projectId)),
      create: protectedProcedure
        .input(z.object({
          projectId: z.number().int().positive(),
          parentId: z.number().int().positive().nullable().optional(),
          code: z.string().min(1).max(40),
          name: z.string().min(1).max(200),
          sortOrder: z.number().int().default(0),
        }))
        .mutation(async ({ input }) => {
          if (input.parentId) {
            const siblings = await listWbsNodes(input.projectId);
            if (!siblings.some((n) => n.id === input.parentId)) {
              throw new TRPCError({ code: "BAD_REQUEST", message: "العقدة الأب غير موجودة ضمن هذا المشروع" });
            }
          }
          return createWbsNode(input);
        }),
      delete: protectedProcedure
        .input(z.object({ id: z.number().int().positive() }))
        .mutation(({ input }) => deleteWbsNode(input.id)),
      stats: protectedProcedure
        .input(z.object({ projectId: z.number().int().positive(), nodeId: z.number().int().positive() }))
        .query(async ({ input }) => {
          const [nodes, acts, entries] = await Promise.all([
            listWbsNodes(input.projectId),
            listActivities(input.projectId),
            listCostEntries(input.projectId),
          ]);
          if (!nodes.some((n) => n.id === input.nodeId)) {
            throw new TRPCError({ code: "NOT_FOUND", message: "عنصر WBS غير موجود ضمن هذا المشروع" });
          }
          return computeWbsStats({
            nodeId: input.nodeId,
            nodes: nodes.map((n) => ({ id: n.id, parentId: n.parentId })),
            activities: acts.map((a) => ({ id: a.id, wbsNodeId: a.wbsNodeId })),
            costEntries: entries.map((e) => ({ id: e.id, wbsNodeId: e.wbsNodeId, plannedCost: Number(e.plannedCost), actualCost: e.actualCost === null ? null : Number(e.actualCost) })),
          });
        }),
    }),

    activities: router({
      list: protectedProcedure
        .input(z.object({ projectId: z.number().int().positive() }))
        .query(({ input }) => listActivities(input.projectId)),
      create: protectedProcedure
        .input(z.object({
          projectId: z.number().int().positive(),
          wbsNodeId: z.number().int().positive().nullable().optional(),
          code: z.string().min(1).max(40),
          name: z.string().min(1).max(200),
          startDate: z.coerce.date(),
          endDate: z.coerce.date(),
          progress: z.number().int().min(0).max(100).default(0),
        }).refine((v) => v.endDate.getTime() >= v.startDate.getTime(), { message: "تاريخ نهاية النشاط يجب أن يكون بعد تاريخ بدايته أو يساويه", path: ["endDate"] }))
        .mutation(async ({ input }) => {
          if (input.wbsNodeId) {
            const nodes = await listWbsNodes(input.projectId);
            if (!nodes.some((n) => n.id === input.wbsNodeId)) {
              throw new TRPCError({ code: "BAD_REQUEST", message: "عنصر WBS المحدد لا ينتمي لهذا المشروع" });
            }
          }
          return createActivity(input);
        }),
      update: protectedProcedure
        .input(z.object({
          id: z.number().int().positive(),
          projectId: z.number().int().positive(),
          startDate: z.coerce.date().optional(),
          endDate: z.coerce.date().optional(),
          progress: z.number().int().min(0).max(100).optional(),
        }))
        .mutation(async ({ input }) => {
          const acts = await listActivities(input.projectId);
          const current = acts.find((a) => a.id === input.id);
          if (!current) throw new TRPCError({ code: "NOT_FOUND", message: "النشاط غير موجود ضمن هذا المشروع" });
          const nextStart = input.startDate ?? new Date(current.startDate);
          const nextEnd = input.endDate ?? new Date(current.endDate);
          if (nextEnd.getTime() < nextStart.getTime()) {
            throw new TRPCError({ code: "BAD_REQUEST", message: "تاريخ نهاية النشاط يجب أن يكون بعد تاريخ بدايته" });
          }
          const { id, projectId, ...patch } = input;
          return updateActivity(id, patch);
        }),
      delete: protectedProcedure
        .input(z.object({ id: z.number().int().positive() }))
        .mutation(({ input }) => deleteActivity(input.id)),
    }),

    dependencies: router({
      list: protectedProcedure
        .input(z.object({ projectId: z.number().int().positive() }))
        .query(({ input }) => listActivityDependencies(input.projectId)),
      create: protectedProcedure
        .input(z.object({
          projectId: z.number().int().positive(),
          predecessorId: z.number().int().positive(),
          successorId: z.number().int().positive(),
        }))
        .mutation(async ({ input }) => {
          const [acts, existingDeps] = await Promise.all([
            listActivities(input.projectId),
            listActivityDependencies(input.projectId),
          ]);
          const projectActivityIds = new Set(acts.map((a) => a.id));
          const edgeError = validateDependencyEdge(
            { predecessorId: input.predecessorId, successorId: input.successorId },
            projectActivityIds,
            existingDeps.map((d) => ({ predecessorId: d.predecessorId, successorId: d.successorId })),
          );
          if (edgeError) throw new TRPCError({ code: "BAD_REQUEST", message: edgeError });

          // Reject the edge up-front if it would introduce a cycle, instead of
          // persisting a broken graph and discovering it on the next CPM read.
          const candidateEdges = [...existingDeps.map((d) => ({ predecessorId: d.predecessorId, successorId: d.successorId })), { predecessorId: input.predecessorId, successorId: input.successorId }];
          const cpmCheck = computeCriticalPath(
            acts.map((a) => ({ id: a.id, startDate: new Date(a.startDate), endDate: new Date(a.endDate) })),
            candidateEdges,
          );
          if (!cpmCheck.ok) throw new TRPCError({ code: "BAD_REQUEST", message: cpmCheck.error });

          return createActivityDependency(input);
        }),
      delete: protectedProcedure
        .input(z.object({ id: z.number().int().positive() }))
        .mutation(({ input }) => deleteActivityDependency(input.id)),
    }),

    cpm: router({
      compute: protectedProcedure
        .input(z.object({ projectId: z.number().int().positive() }))
        .query(async ({ input }) => {
          const [acts, deps] = await Promise.all([
            listActivities(input.projectId),
            listActivityDependencies(input.projectId),
          ]);
          const result = computeCriticalPath(
            acts.map((a) => ({ id: a.id, startDate: new Date(a.startDate), endDate: new Date(a.endDate) })),
            deps.map((d) => ({ predecessorId: d.predecessorId, successorId: d.successorId })),
          );
          if (!result.ok) throw new TRPCError({ code: "BAD_REQUEST", message: result.error });
          return result;
        }),
    }),

    costCatalog: router({
      list: protectedProcedure
        .input(z.object({ search: z.string().optional(), category: z.string().optional() }).optional())
        .query(({ input }) => listCostCatalog(input ?? {})),
    }),

    costEntries: router({
      list: protectedProcedure
        .input(z.object({ projectId: z.number().int().positive() }))
        .query(({ input }) => listCostEntries(input.projectId)),
      create: protectedProcedure
        .input(z.object({
          projectId: z.number().int().positive(),
          wbsNodeId: z.number().int().positive().nullable().optional(),
          activityId: z.number().int().positive().nullable().optional(),
          catalogItemId: z.number().int().positive(),
          quantity: z.number().positive(),
        }))
        .mutation(async ({ input, ctx }) => {
          const item = await getCostCatalogItem(input.catalogItemId);
          if (!item) throw new TRPCError({ code: "NOT_FOUND", message: "بند التكلفة غير موجود في الكتالوج أو غير فعال" });

          if (input.wbsNodeId) {
            const nodes = await listWbsNodes(input.projectId);
            if (!nodes.some((n) => n.id === input.wbsNodeId)) {
              throw new TRPCError({ code: "BAD_REQUEST", message: "عنصر WBS المحدد لا ينتمي لهذا المشروع" });
            }
          }
          if (input.activityId) {
            const acts = await listActivities(input.projectId);
            if (!acts.some((a) => a.id === input.activityId)) {
              throw new TRPCError({ code: "BAD_REQUEST", message: "النشاط المحدد لا ينتمي لهذا المشروع" });
            }
          }

          const unitPrice = Number(item.unitPrice);
          const plannedCost = Math.round(input.quantity * unitPrice * 100) / 100;

          return createCostEntry({
            projectId: input.projectId,
            wbsNodeId: input.wbsNodeId ?? null,
            activityId: input.activityId ?? null,
            catalogItemId: item.id,
            quantity: input.quantity.toFixed(3),
            unitPriceSnapshot: unitPrice.toFixed(2),
            plannedCost: plannedCost.toFixed(2),
            createdBy: ctx.user.id,
          });
        }),
      updateActual: protectedProcedure
        .input(z.object({
          id: z.number().int().positive(),
          actualCost: z.number().nonnegative(),
          progress: z.number().int().min(0).max(100),
          measurementDate: z.coerce.date().optional(),
        }))
        .mutation(({ input }) => updateCostEntry(input.id, {
          actualCost: input.actualCost.toFixed(2),
          progress: input.progress,
          measurementDate: input.measurementDate ?? new Date(),
        })),
      delete: protectedProcedure
        .input(z.object({ id: z.number().int().positive() }))
        .mutation(({ input }) => deleteCostEntry(input.id)),
    }),

    evm: router({
      compute: protectedProcedure
        .input(z.object({ projectId: z.number().int().positive(), asOfDate: z.coerce.date() }))
        .query(async ({ input }) => {
          const [entries, acts, projectRows] = await Promise.all([
            listCostEntries(input.projectId),
            listActivities(input.projectId),
            listProjects(),
          ]);
          const project = projectRows.find((p) => p.id === input.projectId);
          const activityById = new Map(acts.map((a) => [a.id, a]));

          const result = computeEvm({
            entries: entries.map((e) => {
              const activity = e.activityId ? activityById.get(e.activityId) : undefined;
              return {
                id: e.id,
                plannedCost: Number(e.plannedCost),
                actualCost: e.actualCost === null ? null : Number(e.actualCost),
                progress: e.progress,
                activityStart: activity ? new Date(activity.startDate) : null,
                activityEnd: activity ? new Date(activity.endDate) : null,
              };
            }),
            asOfDate: input.asOfDate,
            projectStartDate: project?.startDate ? new Date(project.startDate) : null,
            projectEndDate: project?.dueDate ? new Date(project.dueDate) : null,
          });

          if (!result.ok) throw new TRPCError({ code: "BAD_REQUEST", message: result.error });
          return result;
        }),
    }),
  }),

  access: router({
    assignRole: protectedProcedure
      .input(z.object({
        userId: z.number().int().positive(),
        projectId: z.number().int().positive().nullable().optional(),
        role: z.enum(["general_manager", "project_manager", "quality_engineer", "maintenance_team", "production_supervisor"]),
      }))
      .mutation(({ input, ctx }) => {
        if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "لا تملك صلاحية تعيين الأدوار" });
        return assignRole({ ...input, createdAt: new Date() });
      }),
  }),
});

export type AppRouter = typeof appRouter;
