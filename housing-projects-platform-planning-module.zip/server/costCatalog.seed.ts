import type { InsertCostCatalogItem } from "../drizzle/schema";

// IMPORTANT: These are illustrative sample items only, so the cost
// calculator has something real to search, select, and compute against out
// of the box. They are NOT the Ministry's official approved price list —
// no such source document was available to this build. Every row is tagged
// with sourceNote below; replace this table with the real catalog (imported
// with real item codes, units, and unit prices from the approved price
// list) before using this for actual budgeting.
const SAMPLE_SOURCE_NOTE = "بيانات تجريبية لأغراض العرض والاختبار — يجب استبدالها بلائحة الأسعار الرسمية المعتمدة قبل الاستخدام الفعلي.";

export const costCatalogSeed: InsertCostCatalogItem[] = [
  { itemCode: "EX-001", description: "أعمال حفر عام بالمعدات الثقيلة", category: "أعمال ترابية", unit: "م3", unitPrice: "18.50", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "EX-002", description: "ردم ودمك طبقات ترابية", category: "أعمال ترابية", unit: "م3", unitPrice: "14.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "CN-001", description: "خرسانة عادية للقواعد", category: "أعمال خرسانية", unit: "م3", unitPrice: "310.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "CN-002", description: "خرسانة مسلحة للأعمدة والجسور", category: "أعمال خرسانية", unit: "م3", unitPrice: "420.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "CN-003", description: "حديد تسليح مشغول", category: "أعمال خرسانية", unit: "طن", unitPrice: "3850.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "MS-001", description: "مباني بلوك خرساني عازل", category: "أعمال بناء", unit: "م2", unitPrice: "62.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "FN-001", description: "أعمال لياسة داخلية وخارجية", category: "أعمال تشطيبات", unit: "م2", unitPrice: "38.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "FN-002", description: "دهانات داخلية بلاستيك", category: "أعمال تشطيبات", unit: "م2", unitPrice: "22.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "FN-003", description: "تركيب بلاط سيراميك أرضيات", category: "أعمال تشطيبات", unit: "م2", unitPrice: "95.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "FN-004", description: "أعمال عزل مائي للأسطح", category: "أعمال تشطيبات", unit: "م2", unitPrice: "48.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "DR-001", description: "توريد وتركيب أبواب خشبية داخلية", category: "أبواب ونوافذ", unit: "عدد", unitPrice: "780.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "DR-002", description: "توريد وتركيب نوافذ ألمنيوم", category: "أبواب ونوافذ", unit: "م2", unitPrice: "410.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "EL-001", description: "نقاط إنارة وتمديدات كهربائية", category: "أعمال كهروميكانيكية", unit: "نقطة", unitPrice: "165.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "PL-001", description: "نقاط صرف صحي وتغذية مياه", category: "أعمال كهروميكانيكية", unit: "نقطة", unitPrice: "210.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "RD-001", description: "أعمال رصف طرق داخلية أسفلت", category: "بنية تحتية", unit: "م2", unitPrice: "58.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
  { itemCode: "RD-002", description: "أرصفة مشاة إنترلوك", category: "بنية تحتية", unit: "م2", unitPrice: "44.00", currency: "SAR", sourceNote: SAMPLE_SOURCE_NOTE, isActive: 1 },
];
