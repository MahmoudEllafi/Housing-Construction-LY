// Work Breakdown Structure helpers.
//
// The one rule that matters here: every statistic shown for a WBS node must
// be scoped to that node PLUS its descendants only — never silently fall
// back to the whole project. subtreeIds() is the single source of truth for
// "what belongs under this node", so every stat function is built on top of
// it instead of re-deriving its own (and potentially inconsistent) scope.

export type WbsNodeInput = {
  id: number;
  parentId: number | null;
};

export function subtreeIds(nodeId: number, nodes: WbsNodeInput[]): Set<number> {
  const childrenOf = new Map<number, number[]>();
  for (const node of nodes) {
    if (node.parentId === null) continue;
    const list = childrenOf.get(node.parentId) ?? [];
    list.push(node.id);
    childrenOf.set(node.parentId, list);
  }

  const result = new Set<number>();
  const stack = [nodeId];
  while (stack.length > 0) {
    const current = stack.pop()!;
    if (result.has(current)) continue; // guards against malformed cyclical parentId chains
    result.add(current);
    for (const child of childrenOf.get(current) ?? []) stack.push(child);
  }
  return result;
}

export function pathToRoot(nodeId: number, nodes: WbsNodeInput[]): number[] {
  const byId = new Map(nodes.map((n) => [n.id, n] as const));
  const path: number[] = [];
  let current: number | null = nodeId;
  const visited = new Set<number>();
  while (current !== null && !visited.has(current)) {
    visited.add(current);
    path.unshift(current);
    current = byId.get(current)?.parentId ?? null;
  }
  return path;
}

export type WbsStatsInput = {
  nodeId: number;
  nodes: WbsNodeInput[];
  activities: { id: number; wbsNodeId: number | null }[];
  costEntries: { id: number; wbsNodeId: number | null; plannedCost: number; actualCost: number | null }[];
};

export type WbsStats = {
  nodeId: number;
  descendantNodeCount: number;
  activityCount: number;
  plannedCost: number;
  actualCost: number;
};

export function computeWbsStats({ nodeId, nodes, activities, costEntries }: WbsStatsInput): WbsStats {
  const scope = subtreeIds(nodeId, nodes);

  const scopedActivities = activities.filter((a) => a.wbsNodeId !== null && scope.has(a.wbsNodeId));
  const scopedEntries = costEntries.filter((e) => e.wbsNodeId !== null && scope.has(e.wbsNodeId));

  const plannedCost = scopedEntries.reduce((sum, e) => sum + e.plannedCost, 0);
  const actualCost = scopedEntries.reduce((sum, e) => sum + (e.actualCost ?? 0), 0);

  return {
    nodeId,
    descendantNodeCount: scope.size - 1,
    activityCount: scopedActivities.length,
    plannedCost: Math.round(plannedCost * 100) / 100,
    actualCost: Math.round(actualCost * 100) / 100,
  };
}
