import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("planning.wbs", () => {
  it("rejects creating a node with a parentId that doesn't exist in the project", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.planning.wbs.create({ projectId: 1, parentId: 999, code: "P-01", name: "حزمة" }),
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });

  it("rejects querying stats for a node not found in the project", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.planning.wbs.stats({ projectId: 1, nodeId: 42 })).rejects.toMatchObject({ code: "NOT_FOUND" });
  });
});

describe("planning.activities", () => {
  it("rejects an activity whose end date precedes its start date at the input-validation layer", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.planning.activities.create({
        projectId: 1,
        code: "A-01",
        name: "حفر",
        startDate: new Date("2026-02-10"),
        endDate: new Date("2026-02-01"),
      }),
    ).rejects.toThrow();
  });
});

describe("planning.dependencies", () => {
  it("rejects a dependency between activities that don't resolve within the project", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.planning.dependencies.create({ projectId: 1, predecessorId: 1, successorId: 2 }),
    ).rejects.toMatchObject({ code: "BAD_REQUEST" });
  });
});

describe("planning.cpm", () => {
  it("returns an empty but valid result when a project has no activities yet", async () => {
    const caller = appRouter.createCaller(createContext());
    const result = await caller.planning.cpm.compute({ projectId: 1 });
    expect(result).toEqual({ ok: true, projectDurationDays: 0, activities: [], criticalPath: [] });
  });
});

describe("planning.costEntries", () => {
  it("rejects a cost entry referencing a catalog item that can't be resolved", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.planning.costEntries.create({ projectId: 1, catalogItemId: 9999, quantity: 10 }),
    ).rejects.toMatchObject({ code: "NOT_FOUND" });
  });

  it("rejects a non-positive quantity at the input-validation layer", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(
      caller.planning.costEntries.create({ projectId: 1, catalogItemId: 1, quantity: 0 }),
    ).rejects.toThrow();
  });
});

describe("planning.evm", () => {
  it("computes a well-formed zeroed result for a project with no cost entries", async () => {
    const caller = appRouter.createCaller(createContext());
    const result = await caller.planning.evm.compute({ projectId: 1, asOfDate: new Date("2026-06-01") });
    expect(result).toMatchObject({ ok: true, pv: 0, ev: 0, ac: 0, sv: 0, cv: 0, spi: null, cpi: null });
  });
});
