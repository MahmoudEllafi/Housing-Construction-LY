import { describe, expect, it } from "vitest";
import { computeWbsStats, pathToRoot, subtreeIds } from "./wbs";

// Tree shape:
// 1 (root)
// ├─ 2
// │  └─ 4
// └─ 3
const nodes = [
  { id: 1, parentId: null },
  { id: 2, parentId: 1 },
  { id: 3, parentId: 1 },
  { id: 4, parentId: 2 },
];

describe("subtreeIds", () => {
  it("includes the node itself and all descendants, not siblings", () => {
    expect(subtreeIds(2, nodes)).toEqual(new Set([2, 4]));
  });

  it("returns the whole tree for the root", () => {
    expect(subtreeIds(1, nodes)).toEqual(new Set([1, 2, 3, 4]));
  });

  it("returns a leaf as just itself", () => {
    expect(subtreeIds(4, nodes)).toEqual(new Set([4]));
  });
});

describe("pathToRoot", () => {
  it("builds the ancestor chain from root to node", () => {
    expect(pathToRoot(4, nodes)).toEqual([1, 2, 4]);
  });
});

describe("computeWbsStats", () => {
  const activities = [
    { id: 1, wbsNodeId: 2 },
    { id: 2, wbsNodeId: 4 },
    { id: 3, wbsNodeId: 3 }, // outside node 2's subtree
  ];
  const costEntries = [
    { id: 1, wbsNodeId: 2, plannedCost: 1000, actualCost: 900 },
    { id: 2, wbsNodeId: 4, plannedCost: 500, actualCost: null },
    { id: 3, wbsNodeId: 3, plannedCost: 99999, actualCost: 99999 }, // must NOT leak into node 2's stats
  ];

  it("scopes activity count and costs to the selected node's subtree only, regression test for the whole-project leak", () => {
    const stats = computeWbsStats({ nodeId: 2, nodes, activities, costEntries });
    expect(stats.activityCount).toBe(2); // activities 1 and 2, not 3
    expect(stats.plannedCost).toBe(1500); // 1000 + 500, NOT +99999
    expect(stats.actualCost).toBe(900); // 900 + 0, NOT +99999
    expect(stats.descendantNodeCount).toBe(1); // node 4
  });

  it("reports zero stats for an empty leaf package", () => {
    const stats = computeWbsStats({ nodeId: 3, nodes, activities: [], costEntries: [] });
    expect(stats.activityCount).toBe(0);
    expect(stats.plannedCost).toBe(0);
    expect(stats.actualCost).toBe(0);
  });

  it("rolls up the full project when the root node is selected", () => {
    const stats = computeWbsStats({ nodeId: 1, nodes, activities, costEntries });
    expect(stats.activityCount).toBe(3);
    expect(stats.plannedCost).toBe(1000 + 500 + 99999);
  });
});
