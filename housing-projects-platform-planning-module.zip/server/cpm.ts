// Critical Path Method (CPM) engine.
//
// Pure, framework-free logic so it can be unit tested directly and reused by
// both the tRPC router (server-side truth) and, if ever needed, the client.
//
// Terminology follows the project glossary (see docs): a "forward pass"
// computes Early Start / Early Finish; a "backward pass" computes
// Late Start / Late Finish; Total Float = Late Start - Early Start; an
// activity is "critical" when its float is (numerically) zero.

export type CpmActivityInput = {
  id: number;
  /** Inclusive calendar start date. */
  startDate: Date;
  /** Inclusive calendar end date. Must not be before startDate. */
  endDate: Date;
};

export type CpmDependencyInput = {
  predecessorId: number;
  successorId: number;
};

export type CpmActivityResult = {
  id: number;
  durationDays: number;
  earlyStart: number;
  earlyFinish: number;
  lateStart: number;
  lateFinish: number;
  totalFloat: number;
  isCritical: boolean;
};

export type CpmSuccess = {
  ok: true;
  projectDurationDays: number;
  activities: CpmActivityResult[];
  /** Ids of critical activities in a valid topological order. */
  criticalPath: number[];
};

export type CpmFailure = {
  ok: false;
  error: string;
};

export type CpmResult = CpmSuccess | CpmFailure;

const FLOAT_EPSILON = 1e-6;

function dayDuration(start: Date, end: Date): number {
  const ms = end.getTime() - start.getTime();
  return Math.max(1, Math.round(ms / 86_400_000) + 1);
}

/**
 * Validates a candidate dependency edge against a known activity id set and
 * the existing edge list. Used before insert so bad edges never reach the
 * database, and reused by computeCriticalPath for defense in depth.
 */
export function validateDependencyEdge(
  edge: CpmDependencyInput,
  knownActivityIds: Set<number>,
  existingEdges: CpmDependencyInput[],
): string | null {
  if (!knownActivityIds.has(edge.predecessorId) || !knownActivityIds.has(edge.successorId)) {
    return "لا يمكن ربط نشاطين لا ينتميان لنفس المشروع";
  }
  if (edge.predecessorId === edge.successorId) {
    return "لا يمكن أن يعتمد النشاط على نفسه";
  }
  const isDuplicate = existingEdges.some(
    (e) => e.predecessorId === edge.predecessorId && e.successorId === edge.successorId,
  );
  if (isDuplicate) {
    return "هذه العلاقة بين النشاطين موجودة بالفعل";
  }
  return null;
}

export function computeCriticalPath(
  activitiesInput: CpmActivityInput[],
  dependenciesInput: CpmDependencyInput[],
): CpmResult {
  if (activitiesInput.length === 0) {
    return { ok: true, projectDurationDays: 0, activities: [], criticalPath: [] };
  }

  const activityIds = new Set(activitiesInput.map((a) => a.id));

  for (const activity of activitiesInput) {
    if (activity.endDate.getTime() < activity.startDate.getTime()) {
      return { ok: false, error: `تاريخ نهاية النشاط رقم ${activity.id} يسبق تاريخ بدايته` };
    }
  }

  // Validate + dedupe edges, guarding against self-dependency, duplicates,
  // and activities from outside the provided set (cross-project leakage).
  const seenEdges = new Set<string>();
  const edges: CpmDependencyInput[] = [];
  for (const edge of dependenciesInput) {
    if (!activityIds.has(edge.predecessorId) || !activityIds.has(edge.successorId)) {
      return { ok: false, error: "توجد علاقة تبعية تشير إلى نشاط خارج نطاق المشروع" };
    }
    if (edge.predecessorId === edge.successorId) {
      return { ok: false, error: `النشاط رقم ${edge.predecessorId} لا يمكن أن يعتمد على نفسه` };
    }
    const key = `${edge.predecessorId}->${edge.successorId}`;
    if (seenEdges.has(key)) {
      return { ok: false, error: "توجد علاقة تبعية مكررة بين نفس النشاطين" };
    }
    seenEdges.add(key);
    edges.push(edge);
  }

  const activityIdList = Array.from(activityIds);

  const predecessorsOf = new Map<number, number[]>();
  const successorsOf = new Map<number, number[]>();
  for (const id of activityIdList) {
    predecessorsOf.set(id, []);
    successorsOf.set(id, []);
  }
  for (const { predecessorId, successorId } of edges) {
    predecessorsOf.get(successorId)!.push(predecessorId);
    successorsOf.get(predecessorId)!.push(successorId);
  }

  // Kahn's algorithm for a topological order; any leftover node after the
  // queue drains indicates a cycle.
  const inDegree = new Map<number, number>();
  for (const id of activityIdList) inDegree.set(id, predecessorsOf.get(id)!.length);
  const queue: number[] = activityIdList.filter((id) => inDegree.get(id) === 0);
  const topoOrder: number[] = [];
  const queueCopy = [...queue];
  while (queueCopy.length > 0) {
    const id = queueCopy.shift()!;
    topoOrder.push(id);
    for (const next of successorsOf.get(id)!) {
      const remaining = inDegree.get(next)! - 1;
      inDegree.set(next, remaining);
      if (remaining === 0) queueCopy.push(next);
    }
  }
  if (topoOrder.length !== activityIds.size) {
    return { ok: false, error: "توجد دورة (Cycle) في علاقات التبعية بين الأنشطة، تحقق من الترتيب المدخل" };
  }

  const durationOf = new Map<number, number>();
  for (const activity of activitiesInput) {
    durationOf.set(activity.id, dayDuration(activity.startDate, activity.endDate));
  }

  // Forward pass (day offsets from project start = 0).
  const earlyStart = new Map<number, number>();
  const earlyFinish = new Map<number, number>();
  for (const id of topoOrder) {
    const preds = predecessorsOf.get(id)!;
    const es = preds.length === 0 ? 0 : Math.max(...preds.map((p) => earlyFinish.get(p)!));
    earlyStart.set(id, es);
    earlyFinish.set(id, es + durationOf.get(id)!);
  }

  const projectDurationDays = Math.max(...Array.from(earlyFinish.values()));

  // Backward pass.
  const lateFinish = new Map<number, number>();
  const lateStart = new Map<number, number>();
  for (let i = topoOrder.length - 1; i >= 0; i--) {
    const id = topoOrder[i];
    const succs = successorsOf.get(id)!;
    const lf = succs.length === 0 ? projectDurationDays : Math.min(...succs.map((s) => lateStart.get(s)!));
    lateFinish.set(id, lf);
    lateStart.set(id, lf - durationOf.get(id)!);
  }

  const results: CpmActivityResult[] = activitiesInput.map((activity) => {
    const id = activity.id;
    const totalFloat = lateStart.get(id)! - earlyStart.get(id)!;
    return {
      id,
      durationDays: durationOf.get(id)!,
      earlyStart: earlyStart.get(id)!,
      earlyFinish: earlyFinish.get(id)!,
      lateStart: lateStart.get(id)!,
      lateFinish: lateFinish.get(id)!,
      totalFloat,
      isCritical: Math.abs(totalFloat) < FLOAT_EPSILON,
    };
  });

  const criticalPath = topoOrder.filter((id) => results.find((r) => r.id === id)!.isCritical);

  return { ok: true, projectDurationDays, activities: results, criticalPath };
}
