import { desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertProject, InsertUser, projects, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.


export async function listProjects() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(projects).orderBy(desc(projects.updatedAt));
}

export async function createProject(input: InsertProject) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(projects).values(input);
  const rows = await db.select().from(projects).where(eq(projects.code, input.code)).limit(1);
  return rows[0];
}


import { reports, roleAssignments, auditLogs, InsertReport, InsertRoleAssignment, InsertAuditLog } from "../drizzle/schema";

export async function listReports() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(reports).orderBy(desc(reports.createdAt));
}

export async function createReport(input: InsertReport) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(reports).values(input);
  const rows = await db.select().from(reports).where(eq(reports.title, input.title)).orderBy(desc(reports.createdAt)).limit(1);
  return rows[0];
}

export async function assignRole(input: InsertRoleAssignment) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(roleAssignments).values(input);
  const rows = await db.select().from(roleAssignments).where(eq(roleAssignments.userId, input.userId)).orderBy(desc(roleAssignments.createdAt)).limit(1);
  return rows[0];
}

export async function writeAuditLog(input: InsertAuditLog) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(auditLogs).values(input);
}


import { maintenanceRequests, qualityInspections, productionEntries, InsertMaintenanceRequest, InsertQualityInspection, InsertProductionEntry } from "../drizzle/schema";

export async function listMaintenanceRequests() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(maintenanceRequests).orderBy(desc(maintenanceRequests.updatedAt));
}

export async function createMaintenanceRequest(input: InsertMaintenanceRequest) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(maintenanceRequests).values(input);
  const rows = await db.select().from(maintenanceRequests).where(eq(maintenanceRequests.requestCode, input.requestCode)).limit(1);
  return rows[0];
}

export async function listQualityInspections() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(qualityInspections).orderBy(desc(qualityInspections.inspectedAt));
}

export async function createQualityInspection(input: InsertQualityInspection) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(qualityInspections).values(input);
  const rows = await db.select().from(qualityInspections).where(eq(qualityInspections.inspectionCode, input.inspectionCode)).limit(1);
  return rows[0];
}

export async function listProductionEntries() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(productionEntries).orderBy(desc(productionEntries.periodStart));
}

export async function createProductionEntry(input: InsertProductionEntry) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(productionEntries).values(input);
  const rows = await db.select().from(productionEntries).where(eq(productionEntries.projectId, input.projectId)).orderBy(desc(productionEntries.createdAt)).limit(1);
  return rows[0];
}


import { attachments, notifications, InsertAttachment } from "../drizzle/schema";

export async function listAttachments(filters: { projectId?: number; inspectionId?: number }) {
  const db = await getDb();
  if (!db) return [];
  if (filters.projectId) return db.select().from(attachments).where(eq(attachments.projectId, filters.projectId)).orderBy(desc(attachments.createdAt));
  if (filters.inspectionId) return db.select().from(attachments).where(eq(attachments.inspectionId, filters.inspectionId)).orderBy(desc(attachments.createdAt));
  return db.select().from(attachments).orderBy(desc(attachments.createdAt));
}

export async function createAttachment(input: InsertAttachment) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(attachments).values(input);
  const rows = await db.select().from(attachments).where(eq(attachments.fileKey, input.fileKey)).limit(1);
  return rows[0];
}

export async function listNotifications(recipientId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notifications).where(eq(notifications.recipientId, recipientId)).orderBy(desc(notifications.createdAt));
}

export async function markNotificationRead(id: number, recipientId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(notifications).set({ readAt: new Date() }).where(eq(notifications.id, id));
  return { success: true } as const;
}


export async function createNotification(input: typeof notifications.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.insert(notifications).values(input).onDuplicateKeyUpdate({ set: { title: input.title, body: input.body } });
  const rows = await db.select().from(notifications).where(eq(notifications.dedupeKey, input.dedupeKey)).limit(1);
  return rows[0];
}


// ---------------------------------------------------------------------------
// Planning module: WBS, activities/dependencies, cost catalog, cost entries
// ---------------------------------------------------------------------------

import { wbsNodes, activities, activityDependencies, costCatalogItems, costEntries, InsertWbsNode, InsertActivity, InsertActivityDependency, InsertCostCatalogItem, InsertCostEntry } from "../drizzle/schema";
import { and } from "drizzle-orm";

export async function listWbsNodes(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(wbsNodes).where(eq(wbsNodes.projectId, projectId)).orderBy(wbsNodes.sortOrder, wbsNodes.id);
}

export async function createWbsNode(input: InsertWbsNode) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(wbsNodes).values(input);
  const insertId = (result as unknown as [{ insertId: number }])[0].insertId;
  const rows = await db.select().from(wbsNodes).where(eq(wbsNodes.id, insertId)).limit(1);
  return rows[0];
}

export async function deleteWbsNode(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(wbsNodes).where(eq(wbsNodes.id, id));
  return { success: true } as const;
}

export async function listActivities(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(activities).where(eq(activities.projectId, projectId)).orderBy(activities.startDate);
}

export async function createActivity(input: InsertActivity) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(activities).values(input);
  const insertId = (result as unknown as [{ insertId: number }])[0].insertId;
  const rows = await db.select().from(activities).where(eq(activities.id, insertId)).limit(1);
  return rows[0];
}

export async function updateActivity(id: number, input: Partial<InsertActivity>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(activities).set(input).where(eq(activities.id, id));
  const rows = await db.select().from(activities).where(eq(activities.id, id)).limit(1);
  return rows[0];
}

export async function deleteActivity(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(activityDependencies).where(eq(activityDependencies.predecessorId, id));
  await db.delete(activityDependencies).where(eq(activityDependencies.successorId, id));
  await db.delete(activities).where(eq(activities.id, id));
  return { success: true } as const;
}

export async function listActivityDependencies(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(activityDependencies).where(eq(activityDependencies.projectId, projectId));
}

export async function createActivityDependency(input: InsertActivityDependency) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(activityDependencies).values(input);
  const insertId = (result as unknown as [{ insertId: number }])[0].insertId;
  const rows = await db.select().from(activityDependencies).where(eq(activityDependencies.id, insertId)).limit(1);
  return rows[0];
}

export async function deleteActivityDependency(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(activityDependencies).where(eq(activityDependencies.id, id));
  return { success: true } as const;
}

export async function listCostCatalog(filters: { search?: string; category?: string } = {}) {
  const db = await getDb();
  if (!db) return [];
  const rows = await db.select().from(costCatalogItems).where(eq(costCatalogItems.isActive, 1)).orderBy(costCatalogItems.itemCode);
  const search = filters.search?.trim().toLowerCase();
  return rows.filter((row) => {
    if (filters.category && row.category !== filters.category) return false;
    if (!search) return true;
    return (
      row.itemCode.toLowerCase().includes(search) ||
      row.description.toLowerCase().includes(search) ||
      row.unit.toLowerCase().includes(search)
    );
  });
}

export async function getCostCatalogItem(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(costCatalogItems).where(and(eq(costCatalogItems.id, id), eq(costCatalogItems.isActive, 1))).limit(1);
  return rows[0];
}

export async function seedCostCatalog(items: InsertCostCatalogItem[]) {
  const db = await getDb();
  if (!db) return;
  for (const item of items) {
    await db.insert(costCatalogItems).values(item).onDuplicateKeyUpdate({
      set: { description: item.description, unit: item.unit, unitPrice: item.unitPrice, category: item.category, sourceNote: item.sourceNote },
    });
  }
}

export async function listCostEntries(projectId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(costEntries).where(eq(costEntries.projectId, projectId)).orderBy(desc(costEntries.createdAt));
}

export async function createCostEntry(input: InsertCostEntry) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db.insert(costEntries).values(input);
  const insertId = (result as unknown as [{ insertId: number }])[0].insertId;
  const rows = await db.select().from(costEntries).where(eq(costEntries.id, insertId)).limit(1);
  return rows[0];
}

export async function updateCostEntry(id: number, input: Partial<InsertCostEntry>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(costEntries).set(input).where(eq(costEntries.id, id));
  const rows = await db.select().from(costEntries).where(eq(costEntries.id, id)).limit(1);
  return rows[0];
}

export async function deleteCostEntry(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(costEntries).where(eq(costEntries.id, id));
  return { success: true } as const;
}
