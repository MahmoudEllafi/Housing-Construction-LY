// Earned Value Management (EVM) engine.
//
// PV  = Planned Value  = value of work planned to be done by the measurement date
// EV  = Earned Value   = value of work actually completed (progress % x planned cost)
// AC  = Actual Cost    = recorded actual expenditure
// SV  = Schedule Variance = EV - PV
// CV  = Cost Variance     = EV - AC
// SPI = Schedule Performance Index = EV / PV  (undefined when PV = 0)
// CPI = Cost Performance Index     = EV / AC  (undefined when AC = 0)

export type EvmCostEntryInput = {
  id: number;
  plannedCost: number;
  actualCost: number | null;
  /** 0-100. Progress used to compute Earned Value for this entry. */
  progress: number;
  /** Optional activity schedule window used to time-phase Planned Value. */
  activityStart: Date | null;
  activityEnd: Date | null;
};

export type EvmInput = {
  entries: EvmCostEntryInput[];
  asOfDate: Date;
  projectStartDate: Date | null;
  projectEndDate: Date | null;
};

export type EvmSuccess = {
  ok: true;
  pv: number;
  ev: number;
  ac: number;
  sv: number;
  cv: number;
  spi: number | null;
  cpi: number | null;
};

export type EvmFailure = {
  ok: false;
  error: string;
};

export type EvmResult = EvmSuccess | EvmFailure;

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function computeEvm(input: EvmInput): EvmResult {
  if (input.projectStartDate && input.projectEndDate && input.projectEndDate.getTime() < input.projectStartDate.getTime()) {
    return { ok: false, error: "تاريخ نهاية المشروع يسبق تاريخ بدايته" };
  }
  if (input.projectStartDate && input.asOfDate.getTime() < input.projectStartDate.getTime()) {
    return { ok: false, error: "تاريخ القياس يسبق تاريخ بداية المشروع" };
  }
  if (input.projectEndDate && input.asOfDate.getTime() > input.projectEndDate.getTime()) {
    return { ok: false, error: "تاريخ القياس يقع بعد نهاية نافذة المشروع" };
  }

  let pv = 0;
  let ev = 0;
  let ac = 0;

  for (const entry of input.entries) {
    if (entry.plannedCost < 0) {
      return { ok: false, error: `التكلفة المخططة للبند رقم ${entry.id} لا يمكن أن تكون سالبة` };
    }
    if (entry.actualCost !== null && entry.actualCost < 0) {
      return { ok: false, error: `التكلفة الفعلية للبند رقم ${entry.id} لا يمكن أن تكون سالبة` };
    }
    if (entry.progress < 0 || entry.progress > 100) {
      return { ok: false, error: `نسبة الإنجاز للبند رقم ${entry.id} يجب أن تكون بين 0 و100` };
    }
    if (entry.activityStart && entry.activityEnd && entry.activityEnd.getTime() < entry.activityStart.getTime()) {
      return { ok: false, error: `تواريخ النشاط المرتبط بالبند رقم ${entry.id} معكوسة` };
    }

    let fractionElapsed = 1;
    if (entry.activityStart && entry.activityEnd) {
      const start = entry.activityStart.getTime();
      const end = entry.activityEnd.getTime();
      const asOf = input.asOfDate.getTime();
      if (asOf <= start) fractionElapsed = 0;
      else if (asOf >= end) fractionElapsed = 1;
      else fractionElapsed = (asOf - start) / (end - start);
    }

    pv += entry.plannedCost * fractionElapsed;
    ev += entry.plannedCost * (entry.progress / 100);
    if (entry.actualCost !== null) ac += entry.actualCost;
  }

  const sv = ev - pv;
  const cv = ev - ac;
  const spi = pv > 0 ? ev / pv : null;
  const cpi = ac > 0 ? ev / ac : null;

  return {
    ok: true,
    pv: round2(pv),
    ev: round2(ev),
    ac: round2(ac),
    sv: round2(sv),
    cv: round2(cv),
    spi: spi !== null ? Math.round(spi * 1000) / 1000 : null,
    cpi: cpi !== null ? Math.round(cpi * 1000) / 1000 : null,
  };
}
