import { describe, expect, it } from "vitest";
import { computeCriticalPath, validateDependencyEdge } from "./cpm";

const d = (s: string) => new Date(s);

describe("computeCriticalPath", () => {
  it("returns an empty result for no activities", () => {
    const result = computeCriticalPath([], []);
    expect(result).toEqual({ ok: true, projectDurationDays: 0, activities: [], criticalPath: [] });
  });

  it("computes a simple linear chain as fully critical", () => {
    // A (3 days) -> B (2 days) -> C (4 days), no slack anywhere.
    const activities = [
      { id: 1, startDate: d("2026-01-01"), endDate: d("2026-01-03") }, // 3 days
      { id: 2, startDate: d("2026-01-04"), endDate: d("2026-01-05") }, // 2 days
      { id: 3, startDate: d("2026-01-06"), endDate: d("2026-01-09") }, // 4 days
    ];
    const dependencies = [
      { predecessorId: 1, successorId: 2 },
      { predecessorId: 2, successorId: 3 },
    ];
    const result = computeCriticalPath(activities, dependencies);
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.projectDurationDays).toBe(9);
    for (const a of result.activities) {
      expect(a.totalFloat).toBe(0);
      expect(a.isCritical).toBe(true);
    }
    expect(result.criticalPath).toEqual([1, 2, 3]);
  });

  it("gives float to the shorter of two parallel paths and marks only the longer one critical", () => {
    // Start -> A (5d, critical) -> End
    // Start -> B (2d, has float) -> End
    const activities = [
      { id: 1, startDate: d("2026-01-01"), endDate: d("2026-01-05") }, // 5 days
      { id: 2, startDate: d("2026-01-01"), endDate: d("2026-01-02") }, // 2 days
      { id: 3, startDate: d("2026-01-06"), endDate: d("2026-01-06") }, // 1 day, joins both
    ];
    const dependencies = [
      { predecessorId: 1, successorId: 3 },
      { predecessorId: 2, successorId: 3 },
    ];
    const result = computeCriticalPath(activities, dependencies);
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const byId = Object.fromEntries(result.activities.map((a) => [a.id, a]));
    expect(byId[1].isCritical).toBe(true);
    expect(byId[1].totalFloat).toBe(0);
    expect(byId[2].isCritical).toBe(false);
    expect(byId[2].totalFloat).toBeGreaterThan(0);
    expect(byId[3].isCritical).toBe(true);
    expect(result.criticalPath).toContain(1);
    expect(result.criticalPath).toContain(3);
    expect(result.criticalPath).not.toContain(2);
  });

  it("rejects an activity whose end date precedes its start date", () => {
    const result = computeCriticalPath(
      [{ id: 1, startDate: d("2026-01-05"), endDate: d("2026-01-01") }],
      [],
    );
    expect(result.ok).toBe(false);
  });

  it("rejects a self-dependency", () => {
    const activities = [{ id: 1, startDate: d("2026-01-01"), endDate: d("2026-01-02") }];
    const result = computeCriticalPath(activities, [{ predecessorId: 1, successorId: 1 }]);
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error).toContain("نفسه");
  });

  it("rejects duplicate dependency edges", () => {
    const activities = [
      { id: 1, startDate: d("2026-01-01"), endDate: d("2026-01-02") },
      { id: 2, startDate: d("2026-01-03"), endDate: d("2026-01-04") },
    ];
    const dependencies = [
      { predecessorId: 1, successorId: 2 },
      { predecessorId: 1, successorId: 2 },
    ];
    const result = computeCriticalPath(activities, dependencies);
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error).toContain("مكررة");
  });

  it("rejects a dependency that points outside the provided activity set (cross-project leakage)", () => {
    const activities = [{ id: 1, startDate: d("2026-01-01"), endDate: d("2026-01-02") }];
    const dependencies = [{ predecessorId: 1, successorId: 999 }];
    const result = computeCriticalPath(activities, dependencies);
    expect(result.ok).toBe(false);
  });

  it("detects a cycle", () => {
    const activities = [
      { id: 1, startDate: d("2026-01-01"), endDate: d("2026-01-02") },
      { id: 2, startDate: d("2026-01-03"), endDate: d("2026-01-04") },
      { id: 3, startDate: d("2026-01-05"), endDate: d("2026-01-06") },
    ];
    const dependencies = [
      { predecessorId: 1, successorId: 2 },
      { predecessorId: 2, successorId: 3 },
      { predecessorId: 3, successorId: 1 },
    ];
    const result = computeCriticalPath(activities, dependencies);
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error).toContain("دورة");
  });
});

describe("validateDependencyEdge", () => {
  const known = new Set([1, 2]);

  it("accepts a valid edge", () => {
    expect(validateDependencyEdge({ predecessorId: 1, successorId: 2 }, known, [])).toBeNull();
  });

  it("rejects an edge referencing an unknown activity", () => {
    expect(validateDependencyEdge({ predecessorId: 1, successorId: 3 }, known, [])).not.toBeNull();
  });

  it("rejects a self edge", () => {
    expect(validateDependencyEdge({ predecessorId: 1, successorId: 1 }, known, [])).not.toBeNull();
  });

  it("rejects a duplicate edge", () => {
    const existing = [{ predecessorId: 1, successorId: 2 }];
    expect(validateDependencyEdge({ predecessorId: 1, successorId: 2 }, known, existing)).not.toBeNull();
  });
});
