import { describe, expect, it } from "vitest";
import { computeEvm } from "./evm";

const d = (s: string) => new Date(s);

describe("computeEvm", () => {
  it("computes PV/EV/AC/SV/CV/SPI/CPI for a simple on-track entry", () => {
    const result = computeEvm({
      entries: [
        {
          id: 1,
          plannedCost: 1000,
          actualCost: 500,
          progress: 50,
          activityStart: d("2026-01-01"),
          activityEnd: d("2026-01-11"),
        },
      ],
      asOfDate: d("2026-01-06"), // exactly halfway through the 10-day window
      projectStartDate: d("2026-01-01"),
      projectEndDate: d("2026-02-01"),
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.pv).toBe(500); // 1000 * 0.5 elapsed
    expect(result.ev).toBe(500); // 1000 * 50%
    expect(result.ac).toBe(500);
    expect(result.sv).toBe(0);
    expect(result.cv).toBe(0);
    expect(result.spi).toBe(1);
    expect(result.cpi).toBe(1);
  });

  it("flags negative schedule variance when behind plan and negative cost variance when over budget", () => {
    const result = computeEvm({
      entries: [
        {
          id: 1,
          plannedCost: 1000,
          actualCost: 900,
          progress: 30, // behind the 100% time-elapsed plan
          activityStart: d("2026-01-01"),
          activityEnd: d("2026-01-02"), // fully elapsed by asOfDate
        },
      ],
      asOfDate: d("2026-01-10"),
      projectStartDate: null,
      projectEndDate: null,
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.pv).toBe(1000);
    expect(result.ev).toBe(300);
    expect(result.sv).toBeLessThan(0);
    expect(result.cv).toBeLessThan(0);
    expect(result.spi).toBeLessThan(1);
    expect(result.cpi).toBeLessThan(1);
  });

  it("returns null SPI/CPI instead of dividing by zero when PV or AC is zero", () => {
    const result = computeEvm({
      entries: [
        {
          id: 1,
          plannedCost: 500,
          actualCost: null,
          progress: 0,
          activityStart: d("2026-02-01"),
          activityEnd: d("2026-02-10"),
        },
      ],
      asOfDate: d("2026-01-01"), // before the activity starts -> PV = 0
      projectStartDate: d("2026-01-01"),
      projectEndDate: d("2026-03-01"),
    });
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.pv).toBe(0);
    expect(result.ac).toBe(0);
    expect(result.spi).toBeNull();
    expect(result.cpi).toBeNull();
  });

  it("rejects a negative planned cost", () => {
    const result = computeEvm({
      entries: [{ id: 1, plannedCost: -10, actualCost: null, progress: 0, activityStart: null, activityEnd: null }],
      asOfDate: d("2026-01-01"),
      projectStartDate: null,
      projectEndDate: null,
    });
    expect(result.ok).toBe(false);
  });

  it("rejects a negative actual cost", () => {
    const result = computeEvm({
      entries: [{ id: 1, plannedCost: 10, actualCost: -5, progress: 0, activityStart: null, activityEnd: null }],
      asOfDate: d("2026-01-01"),
      projectStartDate: null,
      projectEndDate: null,
    });
    expect(result.ok).toBe(false);
  });

  it("rejects progress outside 0-100", () => {
    const result = computeEvm({
      entries: [{ id: 1, plannedCost: 10, actualCost: null, progress: 140, activityStart: null, activityEnd: null }],
      asOfDate: d("2026-01-01"),
      projectStartDate: null,
      projectEndDate: null,
    });
    expect(result.ok).toBe(false);
  });

  it("rejects a reversed activity date window", () => {
    const result = computeEvm({
      entries: [
        { id: 1, plannedCost: 10, actualCost: null, progress: 0, activityStart: d("2026-02-01"), activityEnd: d("2026-01-01") },
      ],
      asOfDate: d("2026-01-15"),
      projectStartDate: null,
      projectEndDate: null,
    });
    expect(result.ok).toBe(false);
  });

  it("rejects a measurement date outside the project window", () => {
    const result = computeEvm({
      entries: [],
      asOfDate: d("2026-05-01"),
      projectStartDate: d("2026-01-01"),
      projectEndDate: d("2026-03-01"),
    });
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.error).toContain("نافذة المشروع");
  });

  it("rejects a project end date before its start date", () => {
    const result = computeEvm({
      entries: [],
      asOfDate: d("2026-01-15"),
      projectStartDate: d("2026-03-01"),
      projectEndDate: d("2026-01-01"),
    });
    expect(result.ok).toBe(false);
  });
});
