import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "test",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("reports procedures", () => {
  it("rejects an invalid report period", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.reports.create({
      title: "تقرير",
      module: "quality",
      periodType: "weekly",
      periodStart: new Date("2026-08-07"),
      periodEnd: new Date("2026-08-01"),
    })).rejects.toThrow();
  });
});

describe("access procedures", () => {
  it("rejects role assignment for non-admin users", async () => {
    const caller = appRouter.createCaller(createContext());
    await expect(caller.access.assignRole({
      userId: 2,
      projectId: null,
      role: "project_manager",
    })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });
});
