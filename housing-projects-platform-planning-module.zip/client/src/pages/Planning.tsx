import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trpc } from "@/lib/trpc";
import {
  AlertTriangle,
  CalendarRange,
  ChevronsUpDown,
  CircleDollarSign,
  FolderTree,
  GanttChart,
  Gauge,
  Link2,
  ListTree,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

function toDateInputValue(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toISOString().slice(0, 10);
}

function formatMoney(value: number, currency = "ر.س"): string {
  return `${value.toLocaleString("ar-SA", { maximumFractionDigits: 2 })} ${currency}`;
}

function SectionCard({ title, icon: Icon, description, children, action }: { title: string; icon: typeof GanttChart; description?: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <Card className="border-white/10 bg-[#102d68]/75">
      <CardHeader className="flex flex-row items-center justify-between gap-3 border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <div className="rounded-lg border border-cyan-200/20 bg-cyan-300/10 p-2 text-cyan-100"><Icon className="h-4 w-4" /></div>
          <div>
            <CardTitle className="text-sm font-black text-white">{title}</CardTitle>
            {description && <p className="mt-1 text-[11px] font-medium text-blue-100/60">{description}</p>}
          </div>
        </div>
        {action}
      </CardHeader>
      <CardContent className="p-5">{children}</CardContent>
    </Card>
  );
}

function EmptyRow({ colSpan, text }: { colSpan: number; text: string }) {
  return (
    <tr>
      <td colSpan={colSpan} className="px-4 py-8 text-center text-xs font-bold text-blue-100/50">{text}</td>
    </tr>
  );
}

// ---------------------------------------------------------------------------
// WBS panel
// ---------------------------------------------------------------------------

type WbsNodeRow = { id: number; parentId: number | null; code: string; name: string };

function buildTree(nodes: WbsNodeRow[]) {
  const byParent = new Map<number | null, WbsNodeRow[]>();
  for (const node of nodes) {
    const list = byParent.get(node.parentId) ?? [];
    list.push(node);
    byParent.set(node.parentId, list);
  }
  return byParent;
}

function WbsTree({ nodes, selectedId, onSelect }: { nodes: WbsNodeRow[]; selectedId: number | null; onSelect: (id: number) => void }) {
  const byParent = useMemo(() => buildTree(nodes), [nodes]);

  function renderChildren(parentId: number | null, depth: number): React.ReactNode {
    const children = byParent.get(parentId) ?? [];
    if (children.length === 0) return null;
    return (
      <ul className={depth === 0 ? "space-y-1" : "mt-1 space-y-1 border-r border-white/10 pr-3"}>
        {children.map((node) => (
          <li key={node.id}>
            <button
              onClick={() => onSelect(node.id)}
              className={`flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2 text-right text-xs font-bold transition-colors ${
                selectedId === node.id ? "bg-cyan-300/15 text-cyan-100" : "text-blue-100/75 hover:bg-white/5"
              }`}
            >
              <span className="truncate">{node.name}</span>
              <span className="font-mono text-[10px] text-blue-100/40">{node.code}</span>
            </button>
            {renderChildren(node.id, depth + 1)}
          </li>
        ))}
      </ul>
    );
  }

  if (nodes.length === 0) {
    return <p className="px-2 py-6 text-center text-xs font-bold text-blue-100/50">لا توجد عناصر WBS بعد. أضف أول حزمة عمل للمشروع.</p>;
  }
  return <div className="max-h-80 overflow-y-auto pr-1">{renderChildren(null, 0)}</div>;
}

function WbsPanel({ projectId }: { projectId: number }) {
  const utils = trpc.useUtils();
  const nodesQuery = trpc.planning.wbs.list.useQuery({ projectId });
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [form, setForm] = useState({ code: "", name: "", parentId: "" as string });

  useEffect(() => {
    if (selectedId === null && nodesQuery.data && nodesQuery.data.length > 0) {
      setSelectedId(nodesQuery.data[0].id);
    }
  }, [nodesQuery.data, selectedId]);

  const statsQuery = trpc.planning.wbs.stats.useQuery(
    { projectId, nodeId: selectedId ?? 0 },
    { enabled: selectedId !== null },
  );

  const createMutation = trpc.planning.wbs.create.useMutation({
    onSuccess: async () => {
      setForm({ code: "", name: "", parentId: "" });
      await utils.planning.wbs.list.invalidate({ projectId });
    },
  });
  const deleteMutation = trpc.planning.wbs.delete.useMutation({
    onSuccess: async () => {
      setSelectedId(null);
      await utils.planning.wbs.list.invalidate({ projectId });
    },
  });

  const nodes = nodesQuery.data ?? [];
  const selectedNode = nodes.find((n) => n.id === selectedId);

  return (
    <div className="grid gap-5 lg:grid-cols-[1.1fr_1.4fr]">
      <SectionCard title="هيكل تجزئة الأعمال (WBS)" icon={ListTree} description="نظّم المشروع إلى حزم وعناصر هرمية، واختر عنصرًا لعرض إحصاءاته.">
        <WbsTree nodes={nodes} selectedId={selectedId} onSelect={setSelectedId} />
        {nodesQuery.isLoading && <p className="mt-3 text-[11px] font-bold text-cyan-200">جارٍ التحميل...</p>}

        <div className="mt-5 space-y-2 border-t border-white/10 pt-4">
          <p className="text-[11px] font-black text-blue-100/60">إضافة عنصر جديد</p>
          <div className="grid grid-cols-2 gap-2">
            <Input placeholder="الكود (مثال: P-01)" value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value }))} className="border-white/10 bg-[#0a2559]/60 text-right text-white placeholder:text-blue-100/35" />
            <Input placeholder="الاسم" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} className="border-white/10 bg-[#0a2559]/60 text-right text-white placeholder:text-blue-100/35" />
          </div>
          <Select value={form.parentId || "root"} onValueChange={(v) => setForm((f) => ({ ...f, parentId: v === "root" ? "" : v }))}>
            <SelectTrigger className="w-full border-white/10 bg-[#0a2559]/60 text-right text-white"><SelectValue placeholder="العنصر الأب" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="root">بلا أب (عنصر جذر)</SelectItem>
              {nodes.map((n) => <SelectItem key={n.id} value={String(n.id)}>{n.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button
            disabled={!form.code || !form.name || createMutation.isPending}
            onClick={() => createMutation.mutate({ projectId, code: form.code, name: form.name, parentId: form.parentId ? Number(form.parentId) : null })}
            className="w-full bg-cyan-300 font-black text-[#08245a] hover:bg-cyan-200"
          >
            <Plus className="ml-2 h-4 w-4" />إضافة إلى الهيكل
          </Button>
          {createMutation.error && <p className="text-[11px] font-bold text-rose-300">{createMutation.error.message}</p>}
        </div>
      </SectionCard>

      <SectionCard
        title={selectedNode ? `إحصاءات: ${selectedNode.name}` : "إحصاءات العنصر المحدد"}
        icon={FolderTree}
        description="الإحصاءات محصورة بنطاق العنصر المحدد وأبنائه فقط، وليست إجمالي المشروع."
        action={selectedNode && (
          <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate({ id: selectedNode.id })} className="h-8 w-8 text-rose-200 hover:bg-rose-300/10">
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      >
        {!selectedNode ? (
          <p className="py-8 text-center text-xs font-bold text-blue-100/50">اختر عنصرًا من الهيكل على اليمين لعرض إحصاءاته.</p>
        ) : statsQuery.isLoading ? (
          <p className="text-[11px] font-bold text-cyan-200">جارٍ الحساب...</p>
        ) : statsQuery.error ? (
          <p className="text-[11px] font-bold text-rose-300">{statsQuery.error.message}</p>
        ) : statsQuery.data ? (
          <div className="grid grid-cols-2 gap-3">
            <StatTile label="عدد الأنشطة ضمن النطاق" value={String(statsQuery.data.activityCount)} />
            <StatTile label="عناصر فرعية" value={String(statsQuery.data.descendantNodeCount)} />
            <StatTile label="التكلفة المخططة" value={formatMoney(statsQuery.data.plannedCost)} />
            <StatTile label="التكلفة الفعلية" value={formatMoney(statsQuery.data.actualCost)} />
          </div>
        ) : null}
      </SectionCard>
    </div>
  );
}

function StatTile({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-white/10 bg-[#0a2559]/60 p-4">
      <p className="text-[10px] font-bold text-blue-100/50">{label}</p>
      <p className="mt-2 text-lg font-black text-white">{value}</p>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Gantt + CPM panel
// ---------------------------------------------------------------------------

type ActivityRow = { id: number; code: string; name: string; startDate: Date | string; endDate: Date | string; progress: number; wbsNodeId: number | null };
type CpmActivityStats = { id: number; durationDays: number; earlyStart: number; earlyFinish: number; lateStart: number; lateFinish: number; totalFloat: number; isCritical: boolean };

function GanttChartSvg({ activities, cpmById }: { activities: ActivityRow[]; cpmById: Map<number, CpmActivityStats> }) {
  if (activities.length === 0) return null;

  const starts = activities.map((a) => new Date(a.startDate).getTime());
  const ends = activities.map((a) => new Date(a.endDate).getTime());
  const rangeStart = Math.min(...starts);
  const rangeEnd = Math.max(...ends);
  const totalDays = Math.max(1, Math.round((rangeEnd - rangeStart) / 86_400_000) + 1);

  const pxPerDay = totalDays > 60 ? 10 : totalDays > 30 ? 16 : 26;
  const labelWidth = 190;
  const rowHeight = 34;
  const chartWidth = labelWidth + totalDays * pxPerDay + 20;
  const chartHeight = activities.length * rowHeight + 30;

  // Weekly gridlines for readability.
  const gridLines: number[] = [];
  for (let d = 0; d <= totalDays; d += 7) gridLines.push(d);

  return (
    <div className="overflow-x-auto rounded-xl border border-white/10 bg-[#0a2559]/40 p-3">
      <svg width={chartWidth} height={chartHeight} role="img" aria-label="مخطط جانت">
        {gridLines.map((d) => (
          <line key={d} x1={labelWidth + d * pxPerDay} x2={labelWidth + d * pxPerDay} y1={0} y2={chartHeight} stroke="rgba(255,255,255,0.06)" strokeWidth={1} />
        ))}
        {activities.map((activity, index) => {
          const start = new Date(activity.startDate).getTime();
          const end = new Date(activity.endDate).getTime();
          const offsetDays = Math.round((start - rangeStart) / 86_400_000);
          const durationDays = Math.max(1, Math.round((end - start) / 86_400_000) + 1);
          const x = labelWidth + offsetDays * pxPerDay;
          const barWidth = durationDays * pxPerDay;
          const y = 14 + index * rowHeight;
          const cpm = cpmById.get(activity.id);
          const critical = cpm?.isCritical ?? false;

          return (
            <g key={activity.id}>
              <text x={labelWidth - 10} y={y + 13} textAnchor="end" fontSize={11} fontWeight={700} fill="#e0f2fe">
                {activity.name.length > 22 ? activity.name.slice(0, 20) + "…" : activity.name}
              </text>
              <rect x={x} y={y} width={barWidth} height={18} rx={4} fill={critical ? "#fb7185" : "#67e8f9"} opacity={0.9} />
              <rect x={x} y={y} width={Math.max(2, (barWidth * activity.progress) / 100)} height={18} rx={4} fill={critical ? "#e11d48" : "#0891b2"} />
              <text x={x + barWidth / 2} y={y + 13} textAnchor="middle" fontSize={9} fontWeight={900} fill="#08245a">
                {activity.progress}%
              </text>
            </g>
          );
        })}
      </svg>
      <div className="mt-3 flex items-center gap-4 text-[10px] font-bold text-blue-100/60">
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-rose-400" /> مسار حرج</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-cyan-300" /> نشاط عادي</span>
      </div>
    </div>
  );
}

function GanttCpmPanel({ projectId }: { projectId: number }) {
  const utils = trpc.useUtils();
  const nodesQuery = trpc.planning.wbs.list.useQuery({ projectId });
  const activitiesQuery = trpc.planning.activities.list.useQuery({ projectId });
  const dependenciesQuery = trpc.planning.dependencies.list.useQuery({ projectId });
  const cpmQuery = trpc.planning.cpm.compute.useQuery({ projectId });

  const [actForm, setActForm] = useState({ code: "", name: "", wbsNodeId: "", startDate: "", endDate: "", progress: "0" });
  const [depForm, setDepForm] = useState({ predecessorId: "", successorId: "" });

  const createActivity = trpc.planning.activities.create.useMutation({
    onSuccess: async () => {
      setActForm({ code: "", name: "", wbsNodeId: "", startDate: "", endDate: "", progress: "0" });
      await Promise.all([utils.planning.activities.list.invalidate({ projectId }), utils.planning.cpm.compute.invalidate({ projectId })]);
    },
  });
  const deleteActivity = trpc.planning.activities.delete.useMutation({
    onSuccess: async () => {
      await Promise.all([
        utils.planning.activities.list.invalidate({ projectId }),
        utils.planning.dependencies.list.invalidate({ projectId }),
        utils.planning.cpm.compute.invalidate({ projectId }),
      ]);
    },
  });
  const createDependency = trpc.planning.dependencies.create.useMutation({
    onSuccess: async () => {
      setDepForm({ predecessorId: "", successorId: "" });
      await Promise.all([utils.planning.dependencies.list.invalidate({ projectId }), utils.planning.cpm.compute.invalidate({ projectId })]);
    },
  });
  const deleteDependency = trpc.planning.dependencies.delete.useMutation({
    onSuccess: async () => {
      await Promise.all([utils.planning.dependencies.list.invalidate({ projectId }), utils.planning.cpm.compute.invalidate({ projectId })]);
    },
  });

  const activities = (activitiesQuery.data ?? []) as ActivityRow[];
  const dependencies = dependenciesQuery.data ?? [];
  const nodes = nodesQuery.data ?? [];

  const cpmById = useMemo(() => {
    const map = new Map<number, CpmActivityStats>();
    if (cpmQuery.data && cpmQuery.data.ok) {
      for (const a of cpmQuery.data.activities) map.set(a.id, a);
    }
    return map;
  }, [cpmQuery.data]);

  return (
    <div className="space-y-5">
      {cpmQuery.error && (
        <div className="flex items-center gap-2 rounded-xl border border-amber-300/30 bg-amber-300/10 p-4 text-xs font-bold text-amber-100">
          <AlertTriangle className="h-4 w-4 shrink-0" />{cpmQuery.error.message}
        </div>
      )}

      <SectionCard title="مخطط Gantt والمسار الحرج" icon={GanttChart} description="يعرض الأنشطة على خط زمني حسب تواريخها الفعلية، مع تمييز الأنشطة الواقعة على المسار الحرج.">
        {activitiesQuery.isLoading ? (
          <p className="text-[11px] font-bold text-cyan-200">جارٍ التحميل...</p>
        ) : activities.length === 0 ? (
          <p className="py-8 text-center text-xs font-bold text-blue-100/50">لا توجد أنشطة بعد. أضف أول نشاط أدناه لبدء الجدولة.</p>
        ) : (
          <GanttChartSvg activities={activities} cpmById={cpmById} />
        )}
      </SectionCard>

      <div className="grid gap-5 lg:grid-cols-2">
        <SectionCard title="إضافة نشاط" icon={Plus}>
          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <Input placeholder="كود النشاط" value={actForm.code} onChange={(e) => setActForm((f) => ({ ...f, code: e.target.value }))} className="border-white/10 bg-[#0a2559]/60 text-right text-white placeholder:text-blue-100/35" />
              <Input placeholder="اسم النشاط" value={actForm.name} onChange={(e) => setActForm((f) => ({ ...f, name: e.target.value }))} className="border-white/10 bg-[#0a2559]/60 text-right text-white placeholder:text-blue-100/35" />
            </div>
            <Select value={actForm.wbsNodeId || "none"} onValueChange={(v) => setActForm((f) => ({ ...f, wbsNodeId: v === "none" ? "" : v }))}>
              <SelectTrigger className="w-full border-white/10 bg-[#0a2559]/60 text-right text-white"><SelectValue placeholder="ربط بعنصر WBS (اختياري)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">بدون ربط</SelectItem>
                {nodes.map((n) => <SelectItem key={n.id} value={String(n.id)}>{n.name}</SelectItem>)}
              </SelectContent>
            </Select>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <p className="mb-1 text-[10px] font-bold text-blue-100/50">تاريخ البداية</p>
                <Input type="date" value={actForm.startDate} onChange={(e) => setActForm((f) => ({ ...f, startDate: e.target.value }))} className="border-white/10 bg-[#0a2559]/60 text-white" />
              </div>
              <div>
                <p className="mb-1 text-[10px] font-bold text-blue-100/50">تاريخ النهاية</p>
                <Input type="date" value={actForm.endDate} onChange={(e) => setActForm((f) => ({ ...f, endDate: e.target.value }))} className="border-white/10 bg-[#0a2559]/60 text-white" />
              </div>
            </div>
            <Button
              disabled={!actForm.code || !actForm.name || !actForm.startDate || !actForm.endDate || createActivity.isPending}
              onClick={() => createActivity.mutate({
                projectId,
                code: actForm.code,
                name: actForm.name,
                wbsNodeId: actForm.wbsNodeId ? Number(actForm.wbsNodeId) : null,
                startDate: new Date(actForm.startDate),
                endDate: new Date(actForm.endDate),
              })}
              className="w-full bg-cyan-300 font-black text-[#08245a] hover:bg-cyan-200"
            >
              <Plus className="ml-2 h-4 w-4" />إضافة النشاط
            </Button>
            {createActivity.error && <p className="text-[11px] font-bold text-rose-300">{createActivity.error.message}</p>}
          </div>
        </SectionCard>

        <SectionCard title="ربط تبعية بين نشاطين" icon={Link2} description="يحمي النظام من التبعية الذاتية والتكرار والدورات (Cycles).">
          <div className="space-y-2">
            <Select value={depForm.predecessorId} onValueChange={(v) => setDepForm((f) => ({ ...f, predecessorId: v }))}>
              <SelectTrigger className="w-full border-white/10 bg-[#0a2559]/60 text-right text-white"><SelectValue placeholder="النشاط السابق (Predecessor)" /></SelectTrigger>
              <SelectContent>{activities.map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name}</SelectItem>)}</SelectContent>
            </Select>
            <Select value={depForm.successorId} onValueChange={(v) => setDepForm((f) => ({ ...f, successorId: v }))}>
              <SelectTrigger className="w-full border-white/10 bg-[#0a2559]/60 text-right text-white"><SelectValue placeholder="النشاط اللاحق (Successor)" /></SelectTrigger>
              <SelectContent>{activities.map((a) => <SelectItem key={a.id} value={String(a.id)}>{a.name}</SelectItem>)}</SelectContent>
            </Select>
            <Button
              disabled={!depForm.predecessorId || !depForm.successorId || createDependency.isPending}
              onClick={() => createDependency.mutate({ projectId, predecessorId: Number(depForm.predecessorId), successorId: Number(depForm.successorId) })}
              className="w-full bg-cyan-300 font-black text-[#08245a] hover:bg-cyan-200"
            >
              <Link2 className="ml-2 h-4 w-4" />إضافة التبعية
            </Button>
            {createDependency.error && <p className="text-[11px] font-bold text-rose-300">{createDependency.error.message}</p>}

            <div className="mt-3 space-y-1.5 border-t border-white/10 pt-3">
              {dependencies.length === 0 ? (
                <p className="text-[11px] font-bold text-blue-100/45">لا توجد تبعيات بعد.</p>
              ) : dependencies.map((dep) => {
                const pred = activities.find((a) => a.id === dep.predecessorId);
                const succ = activities.find((a) => a.id === dep.successorId);
                return (
                  <div key={dep.id} className="flex items-center justify-between gap-2 rounded-lg bg-white/[.03] px-3 py-2 text-[11px] font-bold text-blue-100/70">
                    <span>{pred?.name ?? "?"} ← {succ?.name ?? "?"}</span>
                    <button onClick={() => deleteDependency.mutate({ id: dep.id })} className="text-rose-300 hover:text-rose-200"><Trash2 className="h-3.5 w-3.5" /></button>
                  </div>
                );
              })}
            </div>
          </div>
        </SectionCard>
      </div>

      <SectionCard title="جدول المسار الحرج (CPM)" icon={ChevronsUpDown} description="Total Float = Late Start - Early Start. الأنشطة ذات الهامش صفر هي الحرجة.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-right">
            <thead className="bg-[#0a2559]/60 text-[10px] font-black text-blue-100/50">
              <tr>
                <th className="px-4 py-3">النشاط</th>
                <th className="px-4 py-3">المدة (يوم)</th>
                <th className="px-4 py-3">البداية المبكرة</th>
                <th className="px-4 py-3">النهاية المبكرة</th>
                <th className="px-4 py-3">البداية المتأخرة</th>
                <th className="px-4 py-3">النهاية المتأخرة</th>
                <th className="px-4 py-3">الهامش (Float)</th>
                <th className="px-4 py-3">الحالة</th>
                <th />
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {activities.length === 0 ? (
                <EmptyRow colSpan={9} text="لا توجد أنشطة بعد." />
              ) : activities.map((activity) => {
                const cpm = cpmById.get(activity.id);
                return (
                  <tr key={activity.id} className="hover:bg-white/[.03]">
                    <td className="px-4 py-3 text-xs font-black text-white">{activity.name}<span className="mr-2 font-mono text-[10px] text-cyan-200/50">{activity.code}</span></td>
                    <td className="px-4 py-3 text-xs font-semibold text-blue-100/70">{cpm?.durationDays ?? "—"}</td>
                    <td className="px-4 py-3 text-xs font-semibold text-blue-100/70">{cpm?.earlyStart ?? "—"}</td>
                    <td className="px-4 py-3 text-xs font-semibold text-blue-100/70">{cpm?.earlyFinish ?? "—"}</td>
                    <td className="px-4 py-3 text-xs font-semibold text-blue-100/70">{cpm?.lateStart ?? "—"}</td>
                    <td className="px-4 py-3 text-xs font-semibold text-blue-100/70">{cpm?.lateFinish ?? "—"}</td>
                    <td className="px-4 py-3 text-xs font-semibold text-blue-100/70">{cpm?.totalFloat ?? "—"}</td>
                    <td className="px-4 py-3">
                      {cpm?.isCritical ? (
                        <Badge variant="outline" className="border-rose-300/30 bg-rose-300/10 text-rose-100">حرج</Badge>
                      ) : (
                        <Badge variant="outline" className="border-cyan-300/30 bg-cyan-300/10 text-cyan-100">عادي</Badge>
                      )}
                    </td>
                    <td className="px-4 py-3"><button onClick={() => deleteActivity.mutate({ id: activity.id })} className="text-rose-300 hover:text-rose-200"><Trash2 className="h-3.5 w-3.5" /></button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Cost calculator panel
// ---------------------------------------------------------------------------

function CostCalculatorPanel({ projectId }: { projectId: number }) {
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const catalogQuery = trpc.planning.costCatalog.list.useQuery({ search: search || undefined });
  const entriesQuery = trpc.planning.costEntries.list.useQuery({ projectId });
  const catalogById = useMemo(() => new Map((catalogQuery.data ?? []).map((c) => [c.id, c])), [catalogQuery.data]);

  const [catalogItemId, setCatalogItemId] = useState("");
  const [quantity, setQuantity] = useState("");
  const selectedItem = catalogItemId ? catalogById.get(Number(catalogItemId)) : undefined;
  const previewCost = selectedItem && quantity ? Number(quantity) * Number(selectedItem.unitPrice) : null;

  const createEntry = trpc.planning.costEntries.create.useMutation({
    onSuccess: async () => {
      setQuantity("");
      await utils.planning.costEntries.list.invalidate({ projectId });
    },
  });
  const deleteEntry = trpc.planning.costEntries.delete.useMutation({
    onSuccess: async () => utils.planning.costEntries.list.invalidate({ projectId }),
  });

  return (
    <div className="space-y-5">
      <div className="rounded-xl border border-amber-300/20 bg-amber-300/5 p-4 text-[11px] font-bold leading-6 text-amber-100/90">
        كتالوج الأسعار المعروض هنا بيانات تجريبية لأغراض العرض، وليس لائحة الأسعار الرسمية المعتمدة. استبدلها ببيانات اللائحة الفعلية قبل استخدام الحاسبة في تسعير حقيقي.
      </div>

      <SectionCard title="حاسبة التكاليف" icon={CircleDollarSign} description="اختر بندًا من كتالوج الأسعار، أدخل الكمية، وسيُحسب التكلفة المخططة تلقائيًا.">
        <div className="grid gap-4 lg:grid-cols-[1.2fr_.8fr]">
          <div className="space-y-2">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-blue-100/35" />
              <Input placeholder="ابحث عن بند بالكود أو الوصف أو الوحدة..." value={search} onChange={(e) => setSearch(e.target.value)} className="border-white/10 bg-[#0a2559]/60 pr-10 text-right text-white placeholder:text-blue-100/35" />
            </div>
            <div className="max-h-64 space-y-1.5 overflow-y-auto rounded-lg border border-white/10 p-2">
              {catalogQuery.isLoading ? (
                <p className="p-3 text-[11px] font-bold text-cyan-200">جارٍ التحميل...</p>
              ) : (catalogQuery.data ?? []).length === 0 ? (
                <p className="p-3 text-[11px] font-bold text-blue-100/50">لا توجد بنود مطابقة.</p>
              ) : (catalogQuery.data ?? []).map((item) => (
                <button
                  key={item.id}
                  onClick={() => setCatalogItemId(String(item.id))}
                  className={`flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2 text-right text-[11px] font-bold transition-colors ${
                    catalogItemId === String(item.id) ? "bg-cyan-300/15 text-cyan-100" : "text-blue-100/75 hover:bg-white/5"
                  }`}
                >
                  <span className="truncate">{item.description}</span>
                  <span className="shrink-0 font-mono text-[10px] text-blue-100/40">{item.itemCode} · {item.unit}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3 rounded-xl border border-white/10 bg-[#0a2559]/60 p-4">
            {!selectedItem ? (
              <p className="py-6 text-center text-xs font-bold text-blue-100/50">اختر بندًا من الكتالوج لعرض تفاصيله.</p>
            ) : (
              <>
                <div><p className="text-[10px] font-bold text-blue-100/50">الوصف</p><p className="text-xs font-black text-white">{selectedItem.description}</p></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><p className="text-[10px] font-bold text-blue-100/50">الوحدة</p><p className="text-xs font-black text-white">{selectedItem.unit}</p></div>
                  <div><p className="text-[10px] font-bold text-blue-100/50">سعر الوحدة</p><p className="text-xs font-black text-white">{formatMoney(Number(selectedItem.unitPrice), selectedItem.currency)}</p></div>
                </div>
                <div>
                  <p className="mb-1 text-[10px] font-bold text-blue-100/50">الكمية</p>
                  <Input type="number" min="0" step="0.001" value={quantity} onChange={(e) => setQuantity(e.target.value)} placeholder="0" className="border-white/10 bg-[#102d68]/70 text-right text-white" />
                </div>
                {previewCost !== null && (
                  <div className="rounded-lg bg-cyan-300/10 p-3 text-center">
                    <p className="text-[10px] font-bold text-cyan-200/70">التكلفة المخططة = الكمية × سعر الوحدة</p>
                    <p className="mt-1 text-lg font-black text-cyan-100">{formatMoney(previewCost, selectedItem.currency)}</p>
                  </div>
                )}
                <Button
                  disabled={!quantity || Number(quantity) <= 0 || createEntry.isPending}
                  onClick={() => createEntry.mutate({ projectId, catalogItemId: Number(catalogItemId), quantity: Number(quantity) })}
                  className="w-full bg-cyan-300 font-black text-[#08245a] hover:bg-cyan-200"
                >
                  <Plus className="ml-2 h-4 w-4" />إضافة بند التكلفة
                </Button>
                {createEntry.error && <p className="text-[11px] font-bold text-rose-300">{createEntry.error.message}</p>}
              </>
            )}
          </div>
        </div>
      </SectionCard>

      <SectionCard title="بنود التكلفة المسجلة" icon={CircleDollarSign}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-right">
            <thead className="bg-[#0a2559]/60 text-[10px] font-black text-blue-100/50">
              <tr>
                <th className="px-4 py-3">البند</th>
                <th className="px-4 py-3">الكمية</th>
                <th className="px-4 py-3">سعر الوحدة</th>
                <th className="px-4 py-3">التكلفة المخططة</th>
                <th className="px-4 py-3">التكلفة الفعلية</th>
                <th className="px-4 py-3">الإنجاز</th>
                <th />
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {(entriesQuery.data ?? []).length === 0 ? (
                <EmptyRow colSpan={7} text="لا توجد بنود تكلفة مسجلة بعد." />
              ) : (entriesQuery.data ?? []).map((entry) => (
                <CostEntryRow key={entry.id} entry={entry} projectId={projectId} onDelete={() => deleteEntry.mutate({ id: entry.id })} />
              ))}
            </tbody>
          </table>
        </div>
      </SectionCard>
    </div>
  );
}

function CostEntryRow({ entry, projectId, onDelete }: { entry: any; projectId: number; onDelete: () => void }) {
  const utils = trpc.useUtils();
  const [editing, setEditing] = useState(false);
  const [actualCost, setActualCost] = useState(entry.actualCost ?? "");
  const [progress, setProgress] = useState(String(entry.progress ?? 0));

  const updateActual = trpc.planning.costEntries.updateActual.useMutation({
    onSuccess: async () => {
      setEditing(false);
      await utils.planning.costEntries.list.invalidate({ projectId });
    },
  });

  return (
    <tr className="hover:bg-white/[.03]">
      <td className="px-4 py-3 text-xs font-black text-white">بند #{entry.catalogItemId}</td>
      <td className="px-4 py-3 text-xs font-semibold text-blue-100/70">{entry.quantity}</td>
      <td className="px-4 py-3 text-xs font-semibold text-blue-100/70">{formatMoney(Number(entry.unitPriceSnapshot))}</td>
      <td className="px-4 py-3 text-xs font-black text-cyan-100">{formatMoney(Number(entry.plannedCost))}</td>
      <td className="px-4 py-3">
        {editing ? (
          <Input type="number" min="0" value={actualCost} onChange={(e) => setActualCost(e.target.value)} className="h-7 w-28 border-white/10 bg-[#0a2559]/60 text-right text-xs text-white" />
        ) : (
          <span className="text-xs font-semibold text-blue-100/70">{entry.actualCost !== null ? formatMoney(Number(entry.actualCost)) : "—"}</span>
        )}
      </td>
      <td className="px-4 py-3">
        {editing ? (
          <Input type="number" min="0" max="100" value={progress} onChange={(e) => setProgress(e.target.value)} className="h-7 w-20 border-white/10 bg-[#0a2559]/60 text-right text-xs text-white" />
        ) : (
          <span className="text-xs font-semibold text-blue-100/70">{entry.progress}%</span>
        )}
      </td>
      <td className="flex items-center gap-2 px-4 py-3">
        {editing ? (
          <Button
            size="sm"
            disabled={updateActual.isPending}
            onClick={() => updateActual.mutate({ id: entry.id, actualCost: Number(actualCost || 0), progress: Number(progress || 0) })}
            className="h-7 bg-cyan-300 px-2 text-[10px] font-black text-[#08245a] hover:bg-cyan-200"
          >
            حفظ
          </Button>
        ) : (
          <button onClick={() => setEditing(true)} className="text-[10px] font-bold text-cyan-200 hover:text-cyan-100">تحديث</button>
        )}
        <button onClick={onDelete} className="text-rose-300 hover:text-rose-200"><Trash2 className="h-3.5 w-3.5" /></button>
      </td>
    </tr>
  );
}

// ---------------------------------------------------------------------------
// EVM panel
// ---------------------------------------------------------------------------

function EvmMetric({ label, value, tone }: { label: string; value: string; tone: "neutral" | "good" | "bad" }) {
  const toneClass = tone === "good" ? "text-emerald-200" : tone === "bad" ? "text-rose-200" : "text-white";
  return (
    <div className="rounded-xl border border-white/10 bg-[#0a2559]/60 p-4">
      <p className="text-[10px] font-bold text-blue-100/50">{label}</p>
      <p className={`mt-2 text-xl font-black ${toneClass}`}>{value}</p>
    </div>
  );
}

function EvmPanel({ projectId }: { projectId: number }) {
  const [asOfDate, setAsOfDate] = useState(toDateInputValue(new Date()));
  const evmQuery = trpc.planning.evm.compute.useQuery({ projectId, asOfDate: new Date(asOfDate) }, { enabled: Boolean(asOfDate) });

  return (
    <div className="space-y-5">
      <SectionCard title="القيمة المكتسبة (EVM)" icon={Gauge} description="PV: القيمة المخططة · EV: القيمة المكتسبة · AC: التكلفة الفعلية">
        <div className="mb-4 flex flex-wrap items-end gap-3">
          <div>
            <p className="mb-1 text-[10px] font-bold text-blue-100/50">تاريخ القياس</p>
            <Input type="date" value={asOfDate} onChange={(e) => setAsOfDate(e.target.value)} className="border-white/10 bg-[#0a2559]/60 text-white" />
          </div>
          <CalendarRange className="h-5 w-5 text-cyan-200/60" />
        </div>

        {evmQuery.isLoading ? (
          <p className="text-[11px] font-bold text-cyan-200">جارٍ الحساب...</p>
        ) : evmQuery.error ? (
          <div className="flex items-center gap-2 rounded-xl border border-amber-300/30 bg-amber-300/10 p-4 text-xs font-bold text-amber-100">
            <AlertTriangle className="h-4 w-4 shrink-0" />{evmQuery.error.message}
          </div>
        ) : evmQuery.data ? (
          <>
            <div className="grid gap-3 sm:grid-cols-3">
              <EvmMetric label="PV — القيمة المخططة" value={formatMoney(evmQuery.data.pv)} tone="neutral" />
              <EvmMetric label="EV — القيمة المكتسبة" value={formatMoney(evmQuery.data.ev)} tone="neutral" />
              <EvmMetric label="AC — التكلفة الفعلية" value={formatMoney(evmQuery.data.ac)} tone="neutral" />
              <EvmMetric label="SV — انحراف الجدول" value={formatMoney(evmQuery.data.sv)} tone={evmQuery.data.sv >= 0 ? "good" : "bad"} />
              <EvmMetric label="CV — انحراف التكلفة" value={formatMoney(evmQuery.data.cv)} tone={evmQuery.data.cv >= 0 ? "good" : "bad"} />
              <EvmMetric label="SPI" value={evmQuery.data.spi !== null ? evmQuery.data.spi.toFixed(2) : "غير محدد"} tone={evmQuery.data.spi === null ? "neutral" : evmQuery.data.spi >= 1 ? "good" : "bad"} />
              <EvmMetric label="CPI" value={evmQuery.data.cpi !== null ? evmQuery.data.cpi.toFixed(2) : "غير محدد"} tone={evmQuery.data.cpi === null ? "neutral" : evmQuery.data.cpi >= 1 ? "good" : "bad"} />
            </div>
            <div className="mt-4 space-y-1.5 rounded-xl border border-white/10 bg-white/[.02] p-4 text-[11px] font-semibold leading-6 text-blue-100/70">
              <p>{evmQuery.data.sv >= 0 ? "SV موجب: قيمة الإنجاز أكبر من المخطط حتى تاريخ القياس." : "SV سالب: يشير إلى تأخر عن الخطة الزمنية حتى تاريخ القياس."}</p>
              <p>{evmQuery.data.cv >= 0 ? "CV موجب: القيمة المكتسبة أكبر من التكلفة الفعلية." : "CV سالب: يشير إلى تجاوز في التكلفة الفعلية."}</p>
            </div>
          </>
        ) : null}
      </SectionCard>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Root page
// ---------------------------------------------------------------------------

export default function Planning() {
  const projectsQuery = trpc.projects.list.useQuery();
  const [projectId, setProjectId] = useState<number | null>(null);

  useEffect(() => {
    if (projectId === null && projectsQuery.data && projectsQuery.data.length > 0) {
      setProjectId(projectsQuery.data[0].id);
    }
  }, [projectsQuery.data, projectId]);

  if (projectsQuery.isLoading) {
    return <p className="text-xs font-bold text-cyan-200">جارٍ تحميل المشاريع...</p>;
  }

  if (!projectsQuery.data || projectsQuery.data.length === 0) {
    return (
      <div className="rounded-2xl border border-white/10 bg-[#102d68]/75 p-10 text-center">
        <p className="text-sm font-bold text-blue-100/70">لا توجد مشاريع بعد. أنشئ مشروعًا من صفحة المشاريع أولًا لتتمكن من التخطيط له.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="relative overflow-hidden rounded-2xl border border-cyan-200/20 bg-gradient-to-l from-[#17458e] via-[#113575] to-[#0d2a60] p-6">
        <div className="relative z-10 flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <p className="mb-2 text-[10px] font-black uppercase tracking-[0.3em] text-cyan-100/70">التخطيط الهندسي / WBS · CPM · Gantt · التكاليف · EVM</p>
            <h1 className="text-2xl font-black text-white md:text-3xl">تخطيط المشروع</h1>
          </div>
          <div className="w-full max-w-xs">
            <Select value={projectId ? String(projectId) : undefined} onValueChange={(v) => setProjectId(Number(v))}>
              <SelectTrigger className="w-full border-white/20 bg-white/10 text-right text-white"><SelectValue placeholder="اختر مشروعًا" /></SelectTrigger>
              <SelectContent>
                {projectsQuery.data.map((p) => <SelectItem key={p.id} value={String(p.id)}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {projectId && (
        <Tabs defaultValue="wbs" className="w-full">
          <TabsList className="flex w-full flex-wrap justify-start gap-1 bg-[#0a2559]/60">
            <TabsTrigger value="wbs">هيكل الأعمال WBS</TabsTrigger>
            <TabsTrigger value="gantt">Gantt والمسار الحرج</TabsTrigger>
            <TabsTrigger value="cost">حاسبة التكاليف</TabsTrigger>
            <TabsTrigger value="evm">القيمة المكتسبة EVM</TabsTrigger>
          </TabsList>
          <TabsContent value="wbs" className="mt-5"><WbsPanel projectId={projectId} /></TabsContent>
          <TabsContent value="gantt" className="mt-5"><GanttCpmPanel projectId={projectId} /></TabsContent>
          <TabsContent value="cost" className="mt-5"><CostCalculatorPanel projectId={projectId} /></TabsContent>
          <TabsContent value="evm" className="mt-5"><EvmPanel projectId={projectId} /></TabsContent>
        </Tabs>
      )}
    </div>
  );
}
