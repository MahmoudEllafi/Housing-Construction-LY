import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import {
  AlertTriangle,
  ArrowLeft,
  Bell,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  CircleDollarSign,
  Clock3,
  Download,
  FileBarChart,
  Filter,
  Hammer,
  MapPin,
  MoreHorizontal,
  Plus,
  Search,
  ShieldCheck,
  TrendingUp,
  Wrench,
} from "lucide-react";

const projectRows = [
  { code: "HOU-2026-014", name: "مجمع النخيل السكني", city: "الرياض", manager: "م. خالد العتيبي", progress: 68, status: "قيد التنفيذ", budget: "248.5 م ر.س", date: "30 سبتمبر 2026" },
  { code: "HOU-2026-009", name: "إسكان واحة جدة", city: "جدة", manager: "م. نورة الحربي", progress: 42, status: "قيد التنفيذ", budget: "186.2 م ر.س", date: "18 ديسمبر 2026" },
  { code: "HOU-2026-021", name: "البنية التحتية - حي السلام", city: "الدمام", manager: "م. فهد القحطاني", progress: 100, status: "مكتمل", budget: "92.8 م ر.س", date: "12 يوليو 2026" },
  { code: "HOU-2026-005", name: "فلل الإسكان الميسر", city: "المدينة المنورة", manager: "م. أحمد الزهراني", progress: 15, status: "متوقف", budget: "317.0 م ر.س", date: "05 مارس 2027" },
];

const statusStyles: Record<string, string> = {
  "قيد التنفيذ": "border-blue-300/30 bg-blue-300/10 text-blue-100",
  "مكتمل": "border-emerald-300/30 bg-emerald-300/10 text-emerald-100",
  "متوقف": "border-amber-300/30 bg-amber-300/10 text-amber-100",
  "مخطط": "border-slate-300/30 bg-slate-300/10 text-slate-100",
};

function MetricCard({ label, value, note, icon: Icon, tone = "cyan" }: { label: string; value: string; note: string; icon: typeof TrendingUp; tone?: "cyan" | "green" | "amber" | "violet" }) {
  const tones = { cyan: "text-cyan-200 bg-cyan-300/10 border-cyan-200/20", green: "text-emerald-200 bg-emerald-300/10 border-emerald-200/20", amber: "text-amber-200 bg-amber-300/10 border-amber-200/20", violet: "text-violet-200 bg-violet-300/10 border-violet-200/20" };
  return <Card className="border-white/10 bg-[#102d68]/75 shadow-[0_14px_35px_rgba(0,0,0,.18)]"><CardContent className="p-5"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-bold tracking-wide text-blue-100/65">{label}</p><p className="mt-2 text-3xl font-black text-white">{value}</p><p className="mt-2 text-xs font-semibold text-emerald-200">{note}</p></div><div className={`rounded-xl border p-3 ${tones[tone]}`}><Icon className="h-5 w-5" /></div></div></CardContent></Card>;
}

function SectionHeading({ eyebrow, title, action }: { eyebrow: string; title: string; action?: string }) {
  return <div className="mb-5 flex items-end justify-between gap-4"><div><p className="mb-1 text-[10px] font-black uppercase tracking-[0.3em] text-cyan-200/70">{eyebrow}</p><h2 className="text-xl font-black text-white">{title}</h2></div>{action && <Button variant="outline" className="border-white/15 bg-white/5 text-xs font-bold text-blue-50 hover:bg-white/10 hover:text-white">{action}<ArrowLeft className="mr-2 h-4 w-4" /></Button>}</div>;
}

function DashboardView() {
  const months = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
  const bars = [48, 54, 45, 61, 58, 69, 76, 73, 83, 78, 88, 92];
  const alerts = [
    { icon: AlertTriangle, title: "تجاوز موعد مستهدف", text: "مشروع إسكان واحة جدة · متأخر 4 أيام", color: "text-amber-200 bg-amber-300/10" },
    { icon: ShieldCheck, title: "ملاحظة جودة حرجة", text: "مجمع النخيل السكني · فحص QI-089", color: "text-rose-200 bg-rose-300/10" },
    { icon: Wrench, title: "طلب صيانة جديد", text: "مبنى الخدمات · أولوية عالية", color: "text-cyan-200 bg-cyan-300/10" },
  ];
  return (
    <div className="space-y-7">
      <div className="relative overflow-hidden rounded-2xl border border-cyan-200/20 bg-gradient-to-l from-[#17458e] via-[#113575] to-[#0d2a60] p-6 shadow-[0_18px_45px_rgba(0,0,0,.22)]">
        <div className="blueprint-crosshair absolute left-10 top-8 h-28 w-28 opacity-70" />
        <div className="relative z-10 max-w-2xl">
          <div className="mb-3 flex items-center gap-2 text-cyan-200"><span className="h-2 w-2 rounded-full bg-cyan-300 shadow-[0_0_15px_#67e8f9]" /><span className="text-[10px] font-black uppercase tracking-[0.3em]">مركز التحكم الوزاري / 07 أغسطس 2026</span></div>
          <h1 className="text-3xl font-black tracking-tight text-white md:text-4xl">صباح الخير، م. خالد</h1>
          <p className="mt-3 max-w-xl text-sm font-medium leading-7 text-blue-100/75">متابعة لحظية لمحفظة المشاريع الهندسية والعمليات التنفيذية. جميع المؤشرات أدناه محدثة وفق آخر دورة بيانات.</p>
        </div>
        <div className="relative z-10 mt-6 flex flex-wrap gap-3"><Button className="bg-cyan-300 font-black text-[#08245a] hover:bg-cyan-200"><Plus className="ml-2 h-4 w-4" />إضافة مشروع</Button><Button variant="outline" className="border-white/20 bg-white/5 font-bold text-white hover:bg-white/10"><FileBarChart className="ml-2 h-4 w-4" />إنشاء تقرير</Button></div>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><MetricCard label="إجمالي المشاريع" value="48" note="↑ 6.4% عن الربع السابق" icon={Hammer} /><MetricCard label="المشاريع النشطة" value="31" note="22 ضمن المسار المخطط" icon={TrendingUp} tone="green" /><MetricCard label="قيمة المحفظة" value="4.82 م" note="ر.س / ميزانية معتمدة" icon={CircleDollarSign} tone="violet" /><MetricCard label="معدل الامتثال" value="94.7%" note="↑ 2.1% هذا الشهر" icon={ShieldCheck} tone="amber" /></div>
      <div className="grid gap-6 xl:grid-cols-[1.45fr_.85fr]">
        <Card className="border-white/10 bg-[#102d68]/75"><CardHeader className="flex flex-row items-center justify-between border-b border-white/10 pb-4"><CardTitle className="text-base font-black text-white">تقدم المحفظة حسب الشهر</CardTitle><Badge className="border-cyan-200/20 bg-cyan-300/10 text-cyan-100">2026</Badge></CardHeader><CardContent className="p-5"><div className="flex h-56 items-end gap-3 border-b border-white/10 pt-4">{bars.map((height, index) => <div key={months[index]} className="group flex flex-1 flex-col items-center gap-2"><div className="relative w-full max-w-10 rounded-t-md bg-gradient-to-t from-blue-400/60 to-cyan-200" style={{ height: height + "%" }}><div className="absolute -top-7 left-1/2 hidden -translate-x-1/2 rounded bg-[#071d4d] px-2 py-1 text-[10px] font-bold text-cyan-100 group-hover:block">{height}%</div></div><span className="text-[10px] font-bold text-blue-100/45">{months[index]}</span></div>)}</div></CardContent></Card>
        <Card className="border-white/10 bg-[#102d68]/75"><CardHeader className="border-b border-white/10 pb-4"><CardTitle className="text-base font-black text-white">التنبيهات التشغيلية</CardTitle></CardHeader><CardContent className="space-y-3 p-5">{alerts.map(({ icon: AlertIcon, title, text, color }) => <div key={title} className="flex items-start gap-3 rounded-xl border border-white/10 bg-[#0a2559]/60 p-3"><div className={`rounded-lg p-2 ${color}`}><AlertIcon className="h-4 w-4" /></div><div className="min-w-0"><p className="text-xs font-black text-white">{title}</p><p className="mt-1 text-[11px] font-medium leading-5 text-blue-100/60">{text}</p></div><ChevronLeft className="mr-auto mt-1 h-4 w-4 shrink-0 text-blue-100/30" /></div>)}</CardContent></Card>
      </div>
      <Card className="border-white/10 bg-[#102d68]/75"><CardHeader className="flex flex-row items-center justify-between border-b border-white/10 pb-4"><CardTitle className="text-base font-black text-white">آخر المشاريع المحدثة</CardTitle><Button variant="ghost" className="text-xs font-bold text-cyan-200 hover:bg-white/5 hover:text-cyan-100">عرض الكل <ArrowLeft className="mr-2 h-4 w-4" /></Button></CardHeader><CardContent className="overflow-x-auto p-0"><ProjectTable /></CardContent></Card>
    </div>
  );
}

function ProjectTable() {
  return <table className="w-full min-w-[760px] text-right"><thead className="bg-[#0a2559]/60 text-[10px] font-black tracking-wide text-blue-100/50"><tr><th className="px-5 py-3">المشروع</th><th className="px-5 py-3">المدينة</th><th className="px-5 py-3">مدير المشروع</th><th className="px-5 py-3">التقدم</th><th className="px-5 py-3">الحالة</th><th className="px-5 py-3">التسليم</th><th /></tr></thead><tbody className="divide-y divide-white/5">{projectRows.map(project => <tr key={project.code} className="transition-colors hover:bg-white/[.03]"><td className="px-5 py-4"><p className="text-xs font-black text-white">{project.name}</p><p className="mt-1 font-mono text-[10px] text-cyan-200/60">{project.code}</p></td><td className="px-5 py-4 text-xs font-bold text-blue-100/75"><span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3 text-cyan-200" />{project.city}</span></td><td className="px-5 py-4 text-xs font-semibold text-blue-100/75">{project.manager}</td><td className="px-5 py-4"><div className="flex items-center gap-2"><Progress value={project.progress} className="h-1.5 w-20 bg-white/10" /><span className="text-[10px] font-black text-white">{project.progress}%</span></div></td><td className="px-5 py-4"><Badge variant="outline" className={statusStyles[project.status]}>{project.status}</Badge></td><td className="px-5 py-4 text-xs font-semibold text-blue-100/70">{project.date}</td><td className="px-5 py-4"><Button size="icon" variant="ghost" className="h-8 w-8 text-blue-100/50 hover:bg-white/10 hover:text-white"><MoreHorizontal className="h-4 w-4" /></Button></td></tr>)}</tbody></table>;
}

function ProjectsDataView() {
  const { data, isLoading, error } = trpc.projects.list.useQuery();
  const rows = data ? data.map((project) => [project.name, project.city, project.managerId ? `مدير #${project.managerId}` : "غير مسند", ({ planned: "مخطط", in_progress: "قيد التنفيذ", completed: "مكتمل", on_hold: "متوقف" } as Record<string, string>)[project.status] ?? project.status, `${project.progress}%`, `${project.budget} ر.س`, project.dueDate ? new Date(project.dueDate).toLocaleDateString("ar-SA") : "غير محدد", project.startDate && project.dueDate ? `${Math.max(0, Math.ceil((new Date(project.dueDate).getTime() - new Date(project.startDate).getTime()) / 86400000))} يوم` : "غير محدد"]) : [];
  return <div className="space-y-3"><ModuleView title="المشاريع" eyebrow="إدارة المشاريع / 01" icon={Hammer} description="سجل مركزي لمتابعة نطاق المشروع وميزانيته وموقعه وتواريخه ونسبة الإنجاز والحالة التنفيذية." accent="from-[#17458e] to-[#0d2a60]" columns={["المشروع", "الموقع", "الجهة المسؤولة", "الحالة", "التقدم", "الميزانية", "التسليم", "المدة"]} rows={rows} />{isLoading && <p className="text-xs font-bold text-cyan-200">جارٍ تحميل بيانات المشاريع...</p>}{error && <p className="text-xs font-bold text-amber-200">تعذر تحميل البيانات الحية، يتم عرض آخر لقطة محفوظة.</p>}</div>;
}

function OperationalDataView({ kind }: { kind: "maintenance" | "quality" | "production" }) {
  const maintenance = trpc.maintenance.list.useQuery(undefined, { enabled: kind === "maintenance" });
  const quality = trpc.quality.list.useQuery(undefined, { enabled: kind === "quality" });
  const production = trpc.production.list.useQuery(undefined, { enabled: kind === "production" });
  const configs = {
    maintenance: { title: "الصيانة", eyebrow: "إدارة الصيانة / 02", icon: Wrench, description: "إدارة دورة طلبات الصيانة من البلاغ والإسناد إلى التنفيذ والتحقق والإغلاق، مع إبراز الأولويات الحرجة.", accent: "from-[#15547a] to-[#0d2a60]", columns: ["رقم الطلب", "الموقع", "الفريق المسؤول", "الأولوية", "الحالة"], fallback: [["MT-2026-184", "مجمع النخيل · مبنى B", "فريق الكهرباء", "عالية", "مفتوح"]] },
    quality: { title: "الجودة", eyebrow: "ضمان الجودة / 03", icon: ShieldCheck, description: "تسجيل الفحوصات والملاحظات وقرارات المطابقة، مع قياس معدل الامتثال وربط الأدلة والصور بالتفتيش.", accent: "from-[#1d437c] to-[#0d2a60]", columns: ["رقم الفحص", "المشروع", "المفتش", "الامتثال", "الحالة"], fallback: [["QI-2026-089", "مجمع النخيل السكني", "م. سارة المطيري", "72%", "حرج"]] },
    production: { title: "الإنتاج", eyebrow: "متابعة الإنتاج / 04", icon: TrendingUp, description: "مقارنة الكميات المنجزة يوميًا وأسبوعيًا مع خطط الإنتاج المعتمدة، واكتشاف الانحرافات مبكرًا.", accent: "from-[#25477a] to-[#0d2a60]", columns: ["الفترة", "المشروع", "المخطط", "المنجز", "الانحراف"], fallback: [["أسبوع 31", "مجمع النخيل السكني", "48 وحدة", "45 وحدة", "-6.2%"]] },
  } as const;
  const config = configs[kind];
  const source = kind === "maintenance" ? maintenance : kind === "quality" ? quality : production;
  const rows = kind === "maintenance" ? (maintenance.data ?? []).map(item => [item.requestCode, item.location, item.assignedTeam ?? "غير مسند", item.priority, item.status]) : kind === "quality" ? (quality.data ?? []).map(item => [item.inspectionCode, `مشروع #${item.projectId}`, `مستخدم #${item.inspectorId ?? "-"}`, `${item.complianceRate}%`, item.criticalObservation ? "حرج" : "مفتوح"]) : (production.data ?? []).map(item => [item.periodType === "daily" ? "يومي" : "أسبوعي", `مشروع #${item.projectId}`, `${item.plannedQuantity} ${item.unit}`, `${item.actualQuantity} ${item.unit}`, "مسجل"]);
  return <div className="space-y-3"><ModuleView {...config} rows={rows as string[][]} />{source.isLoading && <p className="text-xs font-bold text-cyan-200">جارٍ تحميل البيانات التشغيلية...</p>}{source.error && <p className="text-xs font-bold text-amber-200">تعذر تحميل البيانات الحية، يتم عرض آخر لقطة محفوظة.</p>}</div>;
}

function ModuleView({ title, eyebrow, icon: Icon, description, accent, columns, rows }: { title: string; eyebrow: string; icon: typeof Wrench; description: string; accent: string; columns: readonly string[]; rows: string[][] }) {
  return <div className="space-y-7"><div className={`relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-l ${accent} p-6`}><div className="relative z-10 flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><p className="mb-2 text-[10px] font-black uppercase tracking-[0.3em] text-cyan-100/70">{eyebrow}</p><div className="flex items-center gap-3"><div className="rounded-xl border border-white/20 bg-white/10 p-3"><Icon className="h-6 w-6 text-cyan-100" /></div><h1 className="text-3xl font-black text-white">{title}</h1></div><p className="mt-3 max-w-2xl text-sm font-medium leading-7 text-blue-100/70">{description}</p></div><Button className="bg-cyan-300 font-black text-[#08245a] hover:bg-cyan-200"><Plus className="ml-2 h-4 w-4" />إضافة جديد</Button></div></div><div className="flex flex-col gap-3 sm:flex-row"><div className="relative flex-1"><Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-blue-100/35" /><Input placeholder="ابحث في السجلات..." className="border-white/10 bg-[#102d68]/70 pr-10 text-right text-white placeholder:text-blue-100/35" /></div><Button variant="outline" className="border-white/10 bg-[#102d68]/70 font-bold text-blue-100 hover:bg-white/10 hover:text-white"><Filter className="ml-2 h-4 w-4" />تصفية متقدمة</Button></div><Card className="overflow-hidden border-white/10 bg-[#102d68]/75"><CardContent className="overflow-x-auto p-0"><table className="w-full min-w-[760px] text-right"><thead className="bg-[#0a2559]/60 text-[10px] font-black text-blue-100/50"><tr>{columns.map(column => <th key={column} className="px-5 py-4">{column}</th>)}<th className="px-5 py-4">إجراء</th></tr></thead><tbody className="divide-y divide-white/5">{rows.length === 0 ? <tr><td colSpan={columns.length + 1} className="px-5 py-12 text-center text-sm font-bold text-blue-100/60">لا توجد سجلات بعد. ابدأ بإضافة أول سجل تشغيلي.</td></tr> : rows.map((row, index) => <tr key={index} className="hover:bg-white/[.03]">{row.map((cell, cellIndex) => <td key={cellIndex} className={`px-5 py-4 text-xs ${cellIndex === 0 ? "font-black text-white" : "font-semibold text-blue-100/70"}`}>{cellIndex === row.length - 1 && (cell === "مفتوح" || cell === "مكتمل" || cell === "حرج" || cell === "متأخر") ? <Badge variant="outline" className={cell === "مكتمل" ? statusStyles["مكتمل"] : cell === "حرج" || cell === "متأخر" ? "border-rose-300/30 bg-rose-300/10 text-rose-100" : "border-cyan-300/30 bg-cyan-300/10 text-cyan-100"}>{cell}</Badge> : cell}</td>)}<td className="px-5 py-4"><Button size="icon" variant="ghost" className="h-8 w-8 text-blue-100/50 hover:bg-white/10 hover:text-white"><MoreHorizontal className="h-4 w-4" /></Button></td></tr>)}</tbody></table></CardContent></Card></div>;
}

export default function Home() {
  const [location] = useLocation();
  if (location === "/") return <DashboardView />;
  if (location === "/projects") return <ProjectsDataView />;
  if (location === "/maintenance") return <OperationalDataView kind="maintenance" />;
  if (location === "/quality") return <OperationalDataView kind="quality" />;
  if (location === "/production") return <OperationalDataView kind="production" />;
  if (location === "/reports") return <ModuleView title="التقارير" eyebrow="مركز التقارير / 05" icon={FileBarChart} description="مركز موحد لإعداد التقارير اليومية والأسبوعية والشهرية وتصديرها بصيغ PDF وExcel بحسب الوحدة والفترة والمشروع." accent="from-[#3b3a83] to-[#0d2a60]" columns={["التقرير", "النطاق", "الفترة", "أنشأه", "الحالة"]} rows={[["تقرير أداء المحفظة", "وزاري", "يوليو 2026", "مكتب إدارة المشاريع", "مكتمل"], ["تقرير الجودة الدوري", "الجودة", "أسبوع 31", "إدارة الجودة", "مفتوح"], ["تقرير الإنتاج", "المشاريع النشطة", "أسبوع 31", "مكتب الإنتاج", "مكتمل"], ["تقرير الصيانة المتأخرة", "المنشآت", "أغسطس 2026", "إدارة الصيانة", "متأخر"]]} />;
  return <ModuleView title="المستخدمون" eyebrow="حوكمة الوصول / 06" icon={Hammer} description="إدارة حسابات الفرق والأدوار والصلاحيات التشغيلية للوصول المنضبط إلى البيانات والعمليات." accent="from-[#17458e] to-[#0d2a60]" columns={["المستخدم", "الدور", "الوحدة", "آخر دخول", "الحالة"]} rows={[["خالد العتيبي", "مدير عام", "الإدارة العليا", "اليوم 08:42", "مفتوح"], ["نورة الحربي", "مدير مشروع", "المشاريع", "اليوم 08:15", "مفتوح"], ["سارة المطيري", "مهندس جودة", "الجودة", "أمس 16:20", "مفتوح"], ["فريق الصيانة المركزي", "فريق الصيانة", "الصيانة", "أمس 14:08", "مكتمل"]]} />;
}
